import React from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { ActionButton } from "@/components/design/Primitives";
import { Coins } from "lucide-react";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/account";
import "@/pages/dashboard-ui.css";

export default function SubscriptionRequiredDialog({ open, onClose, onRenew, message, cta }) {
  const { t, dir } = useI18n("account");
  return <Dialog open={open} onOpenChange={(value) => !value && onClose()}>
    <DialogContent className="mr7-topup-dialog" dir={dir} data-testid="topup-required-dialog">
      <DialogHeader className="text-start">
        <DialogTitle className="mr7-topup-title flex items-center gap-2 text-lg font-medium"><Coins size={20} className="mr7-topup-icon" /> {t("يلزم شحن الرصيد")}</DialogTitle>
        <DialogDescription className="mr7-topup-copy text-sm leading-relaxed pt-2">{t(message || "نفد رصيد التوكنات. يمكنك شحن المحفظة للمتابعة.")}</DialogDescription>
      </DialogHeader>
      <p className="mr7-topup-copy text-xs leading-relaxed">{t("يمكنك العودة إلى حسابك ومشاريعك وإدارة الرصيد من المحفظة.")}</p>
      <DialogFooter className="flex gap-2 pt-2 sm:justify-end">
        <ActionButton tone="ghost" className="mr7-topup-button mr7-topup-button-ghost" onClick={onClose} data-testid="topup-dismiss-btn">{t("ليس الآن")}</ActionButton>
        <ActionButton className="mr7-topup-button mr7-topup-button-primary" onClick={onRenew} data-testid="topup-renew-btn">{t(cta || "شحن الرصيد")}</ActionButton>
      </DialogFooter>
    </DialogContent>
  </Dialog>;
}
