import React, { act } from "react";
import { createRoot } from "react-dom/client";
import SettingsDialog from "./SettingsDialog";
import { toast } from "sonner";

const mockAuthFetch = jest.fn();
const mockDeleteChat = jest.fn();
const mockRefresh = jest.fn();
const mockBalanceRefresh = jest.fn();
const mockSetPrefs = jest.fn();
const mockChats = [{ id: "chat1" }, { id: "chat2" }];
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ authFetch: mockAuthFetch, refresh: mockRefresh }) }));
jest.mock("@/context/TokensContext", () => ({ useTokens: () => ({ refresh: mockBalanceRefresh }) }));
jest.mock("@/context/ChatContext", () => ({ useChat: () => ({ chats: mockChats, deleteChat: mockDeleteChat, prefs: { autoSuffix: { enabled: false, text: "Suffix" } }, setPrefs: mockSetPrefs }) }));
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
jest.mock("@/components/ui/dialog", () => {
  const Element = ({ children }) => require("react").createElement("div", null, children);
  return { Dialog: Element, DialogContent: Element, DialogHeader: Element, DialogTitle: Element, DialogDescription: Element };
});
jest.mock("@/components/ui/button", () => ({ Button: ({ variant, ...props }) => require("react").createElement("button", props) }));
jest.mock("@/components/ui/input", () => ({ Input: (props) => require("react").createElement("input", props) }));
jest.mock("@/components/ui/textarea", () => ({ Textarea: (props) => require("react").createElement("textarea", props) }));
jest.mock("@/components/ui/label", () => ({ Label: (props) => require("react").createElement("label", props) }));
jest.mock("@/components/ui/switch", () => ({ Switch: ({ checked, onCheckedChange, ...props }) => require("react").createElement("input", { ...props, type: "checkbox", checked, onChange: (e) => onCheckedChange(e.target.checked) }) }));
let container, root;
beforeEach(async () => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  [mockAuthFetch, mockDeleteChat, mockRefresh, mockBalanceRefresh, mockSetPrefs, toast.success, toast.error].forEach((f) => f.mockReset());
  jest.spyOn(window, "confirm").mockReturnValue(true);
  container = document.createElement("div"); document.body.appendChild(container); root = createRoot(container);
  await act(async () => root.render(<SettingsDialog open onOpenChange={() => {}} />));
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); jest.restoreAllMocks(); });
const click = async (testId) => { await act(async () => container.querySelector(`[data-testid="${testId}"]`).click()); };
async function enterCoupon() {
  await act(async () => {
    const input = container.querySelector('[data-testid="redeem-input"]');
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(input, "REPEAT");
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

test("does not advertise unsupported reasoning/search and allows editing suffix", () => {
  expect(container.querySelector('[data-testid="deepthink-switch"]')).toBeNull();
  expect(container.querySelector('[data-testid="websearch-switch"]')).toBeNull();
  expect(container.querySelector(".deepseek-settings-nav")).not.toBeNull();
  expect(container.querySelector('[data-testid="model-status"]')).not.toBeNull();
  expect(container.querySelector('[data-testid="auto-suffix-text"]').value).toBe("Suffix");
});

test("Clear all invokes the real deletion hook for every current-project chat", async () => {
  mockDeleteChat.mockResolvedValue(true);
  await click("clear-all-btn");
  expect(mockDeleteChat.mock.calls).toEqual([["chat1"], ["chat2"]]);
  expect(toast.success).toHaveBeenCalledWith("تم حذف محادثات هذا المشروع.");
});

test("partial deletion failure does not report successful clearing", async () => {
  mockDeleteChat.mockResolvedValue(false);
  await click("clear-all-btn");
  expect(mockDeleteChat).toHaveBeenCalledTimes(1);
  expect(toast.success).not.toHaveBeenCalled();
  expect(toast.error).toHaveBeenCalled();
  expect(container.querySelector('[data-testid="clear-all-btn"]').disabled).toBe(false);
});

test("coupon network retry keeps the same idempotency key and restores controls", async () => {
  mockAuthFetch.mockRejectedValueOnce(new TypeError("network unavailable")).mockResolvedValueOnce({ ok: true, json: async () => ({ tokens: 7 }) });
  await enterCoupon(); await click("redeem-btn");
  expect(container.querySelector('[data-testid="redeem-btn"]').disabled).toBe(false);
  await click("redeem-btn");
  const bodies = mockAuthFetch.mock.calls.map((call) => JSON.parse(call[1].body));
  expect(bodies[0].idempotency_key).toBe(bodies[1].idempotency_key);
  expect(bodies[0].idempotency_key).toBeTruthy();
  expect(mockRefresh).toHaveBeenCalledTimes(1);
  expect(mockBalanceRefresh).toHaveBeenCalledTimes(1);
  expect(toast.success).toHaveBeenCalledTimes(1);
});
