import React, { memo, useRef } from "react";
import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import CodeBlock from "@/components/chat/CodeBlock";
import { parseStreamMarkdown } from "./streamMarkdown";
import "./stream-rendering.css";

const REMARK_PLUGINS = [remarkGfm];
const URL_RE = /\b(?:https?:\/\/|www\.)[^\s<>`"')\]]+[^\s<>`"'),.;:!?\]]/g;
const CODE_SPLIT_RE = /(```[\s\S]*?```|~~~[\s\S]*?~~~|`[^`\n]+`)/g;
const SAFE_PROTOCOL_RE = /^(?:https?:|mailto:|tel:)/i;
const REFERENCE_RE = /^[ \t]{0,3}\[[^\]\r\n]+\]:[^\r\n]+/gm;
const INLINE_SYNTAX_RE = /[`*_~[\]<>\\]|https?:\/\/|www\./;

function safeUrlTransform(value) {
  const url = String(value || "").trim();
  if (/^[a-z][a-z\d+.-]*:/i.test(url) && !SAFE_PROTOCOL_RE.test(url)) return "";
  return url;
}

function linkifyOutsideCode(text) {
  if (!text || typeof text !== "string") return text || "";
  return text.split(CODE_SPLIT_RE).map((chunk) => {
    if (chunk.startsWith("```") || chunk.startsWith("~~~") || (chunk.startsWith("`") && chunk.endsWith("`"))) return chunk;
    return chunk.replace(URL_RE, (url, offset, full) => {
      const linePrefix = full.slice(full.lastIndexOf("\n", offset - 1) + 1, offset);
      // Definitions must retain their raw destination; wrapping it in another
      // Markdown link would break references shared by the streamed blocks.
      if (/^[ \t]{0,3}\[[^\]]+\]:[ \t]*<?$/.test(linePrefix)) return url;
      if (full.slice(Math.max(0, offset - 2), offset) === "](" || full[offset - 1] === "<" || full[offset - 1] === "(") return url;
      return `[${url}](${url.startsWith("www.") ? `http://${url}` : url})`;
    });
  }).join("");
}

function extractText(children) {
  if (children == null) return "";
  if (typeof children === "string") return children;
  if (Array.isArray(children)) return children.map(extractText).join("");
  if (typeof children === "object" && children.props) return extractText(children.props.children);
  return String(children);
}
function AnchorRenderer({ node, href, ...rest }) {
  const safeHref = safeUrlTransform(href);
  if (!safeHref) return <span {...rest} />;
  return <a href={safeHref} target="_blank" rel="noopener noreferrer" {...rest} />;
}
// react-markdown v10 has no `inline` prop: fenced blocks arrive wrapped in <pre>.
function PreRenderer({ children }) {
  const child = React.Children.toArray(children)[0];
  const className = child?.props?.className || "";
  const match = /language-([\w-]+)/.exec(className);
  const value = extractText(child?.props?.children).replace(/\n$/, "");
  return <CodeBlock language={match?.[1] || "text"} value={value} streaming={false} />;
}
function CodeRenderer({ node, className, children, ...props }) {
  return <code dir="ltr" className={className} {...props}>{children}</code>;
}
const MARKDOWN_COMPONENTS = { pre: PreRenderer, code: CodeRenderer, a: AnchorRenderer };

function simpleProse(value) {
  const text = value.trim();
  if (!text) return null;
  const heading = /^ {0,3}(#{1,6})[ \t]+([^\n]+)\n?$/.exec(text);
  if (heading && !INLINE_SYNTAX_RE.test(heading[2])) {
    return React.createElement(`h${heading[1].length}`, null, heading[2].replace(/[ \t]+#+[ \t]*$/, ""));
  }
  // Only unambiguous prose bypasses the Markdown engine. Lists, tables,
  // references, quotes, emphasis and code always retain the full GFM path.
  if (!INLINE_SYNTAX_RE.test(text) && !/[\n\r|]/.test(text)
      && !/^(?: {4}|[-+>]\s|\d+[.)]\s|#{1,6}\s|!)/.test(value)) {
    return <p>{text}</p>;
  }
  return null;
}
const MarkdownSegment = memo(function MarkdownSegment({ part, definitions }) {
  const simple = simpleProse(part.value);
  if (simple) return <div className="markdown-stream-segment">{simple}</div>;
  const source = linkifyOutsideCode(part.value) + (definitions ? `\n\n${definitions}\n` : "");
  return <div className="markdown-stream-segment"><ReactMarkdown remarkPlugins={REMARK_PLUGINS} components={MARKDOWN_COMPONENTS} urlTransform={safeUrlTransform}>{source}</ReactMarkdown></div>;
}, (previous, next) => previous.part === next.part && previous.definitions === next.definitions);

const StreamParts = memo(function StreamParts({ segments, tail, definitions }) {
  const parts = tail ? [...segments, tail] : segments;
  return parts.map((part, index) => part.type === "code"
    ? <CodeBlock key={part.streamKey || index} language={part.language} value={part.value} streaming />
    : <MarkdownSegment key={part.streamKey || index} part={part} definitions={definitions} />);
}, (previous, next) => previous.segments === next.segments && previous.tail === next.tail && previous.definitions === next.definitions);

function HistoryContent({ source }) {
  return <div className="markdown"><ReactMarkdown remarkPlugins={REMARK_PLUGINS} components={MARKDOWN_COMPONENTS} urlTransform={safeUrlTransform}>{linkifyOutsideCode(source)}</ReactMarkdown></div>;
}

function sharedDefinitions(state, previous, final) {
  const reset = !previous || state.segments.length < previous.count;
  const context = reset ? { count: 0, lines: [], seen: new Set(), value: "" } : previous;
  let changed = false;
  const collect = (part) => {
    if (!part || part.type !== "text") return;
    for (const match of part.value.matchAll(REFERENCE_RE)) {
      if (context.seen.has(match[0])) continue;
      context.seen.add(match[0]); context.lines.push(match[0]); changed = true;
    }
  };
  for (let i = context.count; i < state.segments.length; i += 1) collect(state.segments[i]);
  context.count = state.segments.length;
  if (final) collect(state.tail);
  if (changed) context.value = context.lines.join("\n");
  return context;
}
function StreamingContent({ source, streaming }) {
  const startedRef = useRef(Boolean(streaming));
  const cacheRef = useRef(null);
  const definitionsRef = useRef(null);
  const wasLive = startedRef.current || streaming;
  if (streaming) startedRef.current = true;
  if (!wasLive) return <HistoryContent source={source} />;
  const state = parseStreamMarkdown(source, cacheRef.current, { finalize: !streaming });
  if (cacheRef.current && !source.startsWith(cacheRef.current.source)) definitionsRef.current = null;
  cacheRef.current = state;
  definitionsRef.current = sharedDefinitions(state, definitionsRef.current, !streaming);
  return <div className="markdown markdown-streaming" data-streaming={streaming ? "1" : "0"}>
    <StreamParts segments={state.segments} tail={state.tail} definitions={definitionsRef.current.value} />
  </div>;
}
function MarkdownImpl({ children, streaming = false }) {
  return <StreamingContent source={children || ""} streaming={streaming} />;
}
export default memo(MarkdownImpl, (previous, next) => previous.children === next.children && previous.streaming === next.streaming);
