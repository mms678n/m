import React from "react";
import { ChatProvider } from "@/context/ChatContext";
import { WorkspaceProvider } from "@/context/WorkspaceContext";
import { SubscriptionProvider } from "@/context/SubscriptionContext";
import { TokensProvider } from "@/context/TokensContext";
import ChatLayout from "@/components/chat/ChatLayout";
import { useI18n } from "@/i18n";

export default function ChatWorkspace({ onOpenDashboard, onOpenAdmin, builderMode = false }) {
  const { dir } = useI18n();
  return <SubscriptionProvider onOpenDashboard={onOpenDashboard}><TokensProvider><WorkspaceProvider><ChatProvider>
    <div className="app-h-svh w-full overflow-hidden bg-bg-main text-white font-sans" dir={dir} data-testid="app-root">
      <ChatLayout builderMode={builderMode} onOpenDashboard={onOpenDashboard} onOpenAdmin={onOpenAdmin} />
    </div>
  </ChatProvider></WorkspaceProvider></TokensProvider></SubscriptionProvider>;
}
