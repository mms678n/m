import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { useAuth } from "@/context/AuthContext";
import { useI18n, LanguageSwitcher } from "@/i18n";
import "@/i18n/catalogs/admin";
import Logo from "@/components/chat/Logo";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter } from "@/components/ui/dialog";
import { Select, SelectTrigger, SelectContent, SelectItem, SelectValue } from "@/components/ui/select";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger, DropdownMenuSeparator } from "@/components/ui/dropdown-menu";
import AdminCoupons from "@/pages/AdminCoupons";
import AdminAdmins from "@/pages/AdminAdmins";
import AdminTelegramVerify from "@/pages/AdminTelegramVerify";
import AdminAISettings from "@/pages/AdminAISettings";
import AdminVPS from "@/pages/AdminVPS";
import { isAdmin, roleLabel } from "@/lib/roles";
import { copyToClipboard } from "@/lib/clipboard";
import { toast } from "sonner";
import { Users, ShieldCheck, Crown, Send, MoreHorizontal, RotateCcw, Trash2, Ban, CheckCircle2, KeyRound, Sparkles, Copy, LogOut, Settings as Cog, Activity, ArrowLeft, Coins, LayoutDashboard, RefreshCw } from "lucide-react";
import { ActionButton, EmptyState, LoadingState, MetricCard, PageHeader, PageShell, Panel, StatusNote } from "@/components/design/Primitives";
import "./admin-ui.css";
import "./admin-details.css";

const PLAN_OPTIONS = [{ id: "basic", label: "1M توكن · $5" }, { id: "pro", label: "5M توكن · $10" }, { id: "unlimited", label: "15M توكن · $20" }];
const TAB_DEFINITIONS = [
  { value: "users", permission: "users", label: "المستخدمون", icon: Users },
  { value: "dashboard", permission: "dashboard", label: "لوحة المؤشرات", icon: LayoutDashboard },
  { value: "coupons", permission: "coupons", label: "القسائم", icon: Sparkles },
  { value: "website_admins", permission: "website_admins", label: "المديرون", icon: ShieldCheck },
  { value: "telegram", permission: "telegram", label: "Telegram", icon: Send },
  { value: "settings", permission: "settings", label: "الإعدادات", icon: Cog },
  { value: "ai_models", permission: "ai_models", label: "نموذج AI", icon: Sparkles },
  { value: "servers", permission: "servers", label: "الخوادم", icon: Cog },
];
const DEFAULT_SETTINGS = { telegram_bot_token: "", telegram_bot_token_configured: false, telegram_chat_id: "", telegram_link: "", telegram_bot_username: "", notify_on_login: false };
const CACHE_TTL = 10_000;
const adminCache = new Map();
function roleLabelSource(role) { return { super_admin: "مدير عام", admin: "مدير", moderator: "مشرف", support: "دعم", user: "مستخدم" }[role] || role || "مستخدم"; }
function fmt(d, formatDate) { if (!d) return "—"; try { return formatDate(d, { dateStyle: "medium", timeStyle: "short" }); } catch { return d; } }
function sessionKey(user) { return user?._id || user?.id || user?.username || "session"; }
function cacheGet(scope, key) { const item = adminCache.get(`${scope}:${key}`); return item && Date.now() - item.at < CACHE_TTL ? item.value : null; }
function cacheSet(scope, key, value) { adminCache.set(`${scope}:${key}`, { value, at: Date.now() }); }
function detailOf(data, fallback) { return typeof data?.detail === "string" ? data.detail : fallback; }
function translateAdminError(message, t) {
  const patterns = [
    [/^فشل تحميل المستخدمين \((.+)\)$/, "فشل تحميل المستخدمين ({status})"],
    [/^فشل تحميل لوحة المؤشرات \((.+)\)$/, "فشل تحميل لوحة المؤشرات ({status})"],
    [/^فشل تحميل الإعدادات \((.+)\)$/, "فشل تحميل الإعدادات ({status})"],
    [/^فشل الحفظ \((.+)\)$/, "فشل الحفظ ({status})"],
    [/^فشلت العملية \((.+)\)$/, "فشلت العملية ({status})"],
  ];
  const found = patterns.find(([pattern]) => pattern.test(message || ""));
  if (found) { const match = found[0].exec(message); return t(found[1], { status: match[1] }); }
  return t(message);
}

export default function Admin({ onExit }) {
  const { authFetch, logout, user } = useAuth();
  const { t, dir, formatNumber, formatDate } = useI18n("admin");
  const can = useCallback((permission) => user?.role === "super_admin" || user?.permissions?.includes(permission), [user]);
  const allowedTabs = useMemo(() => TAB_DEFINITIONS.filter(({ permission }) => permission === "servers" ? user?.role === "super_admin" : can(permission)).map(({ value }) => value), [can, user?.role]);
  const firstAllowedTab = allowedTabs[0] || null;
  const [tab, setTab] = useState(firstAllowedTab);
  const [stats, setStats] = useState(null);
  const [users, setUsers] = useState([]);
  const [query, setQuery] = useState("");
  const [userStatus, setUserStatus] = useState("all");
  const [userSort, setUserSort] = useState("recent");
  const [loading, setLoading] = useState(false);
  const [statsLoading, setStatsLoading] = useState(false);
  const [settingsLoading, setSettingsLoading] = useState(false);
  const [loadErrors, setLoadErrors] = useState({ users: "", stats: "", settings: "" });
  const [settings, setSettings] = useState({ ...DEFAULT_SETTINGS });
  const [broadcast, setBroadcast] = useState("");
  const [subTarget, setSubTarget] = useState(null);
  const [pwResult, setPwResult] = useState(null);
  const [recResult, setRecResult] = useState(null);
  const [savingSettings, setSavingSettings] = useState(false);
  const [actionError, setActionError] = useState("");
  const usersAbort = useRef(null); const statsAbort = useRef(null); const settingsAbort = useRef(null);
  const usersRequest = useRef(0); const statsRequest = useRef(0); const settingsRequest = useRef(0);
  const session = sessionKey(user);

  useEffect(() => { if (!allowedTabs.includes(tab)) setTab(firstAllowedTab); }, [allowedTabs, firstAllowedTab, tab]);

  const loadUsers = useCallback(async (q = "", { force = false } = {}) => {
    if (!can("users")) return;
    usersAbort.current?.abort(); const id = ++usersRequest.current;
    const cacheKey = `${session}:${q}`; const cached = !force && cacheGet("users", cacheKey);
    if (cached) { setUsers(cached); setLoadErrors((e) => ({ ...e, users: "" })); setLoading(false); return; }
    const controller = new AbortController(); usersAbort.current = controller;
    setLoading(true); setLoadErrors((e) => ({ ...e, users: "" }));
    try {
      const r = await authFetch(`/admin/users${q ? `?q=${encodeURIComponent(q)}` : ""}`, { signal: controller.signal }); const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(detailOf(data, `فشل تحميل المستخدمين (${r.status})`));
      if (controller.signal.aborted || id !== usersRequest.current) return;
      const next = Array.isArray(data) ? data : []; cacheSet("users", cacheKey, next); setUsers(next);
    } catch (e) { if (e?.name !== "AbortError" && id === usersRequest.current) setLoadErrors((errors) => ({ ...errors, users: e?.message || "تعذّر تحميل المستخدمين" })); }
    finally { if (id === usersRequest.current) setLoading(false); }
  }, [authFetch, can, session]);

  const loadStats = useCallback(async ({ force = false } = {}) => {
    if (!can("dashboard")) return;
    statsAbort.current?.abort(); const id = ++statsRequest.current;
    const cached = !force && cacheGet("stats", session);
    if (cached) { setStats(cached); setLoadErrors((e) => ({ ...e, stats: "" })); setStatsLoading(false); return; }
    const controller = new AbortController(); statsAbort.current = controller;
    setStatsLoading(true); setLoadErrors((e) => ({ ...e, stats: "" }));
    try {
      const r = await authFetch("/admin/stats", { signal: controller.signal }); const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(detailOf(data, `فشل تحميل لوحة المؤشرات (${r.status})`));
      if (controller.signal.aborted || id !== statsRequest.current) return;
      cacheSet("stats", session, data); setStats(data);
    } catch (e) { if (e?.name !== "AbortError" && id === statsRequest.current) setLoadErrors((errors) => ({ ...errors, stats: e?.message || "تعذّر تحميل لوحة المؤشرات" })); }
    finally { if (id === statsRequest.current) setStatsLoading(false); }
  }, [authFetch, can, session]);

  const loadSettings = useCallback(async ({ force = false } = {}) => {
    if (!can("settings")) return;
    settingsAbort.current?.abort(); const id = ++settingsRequest.current;
    const cached = !force && cacheGet("settings", session);
    if (cached) { setSettings(cached); setLoadErrors((e) => ({ ...e, settings: "" })); setSettingsLoading(false); return; }
    const controller = new AbortController(); settingsAbort.current = controller;
    setSettingsLoading(true); setLoadErrors((e) => ({ ...e, settings: "" }));
    try {
      const r = await authFetch("/admin/settings", { signal: controller.signal }); const data = await r.json().catch(() => ({}));
      if (!r.ok) throw new Error(detailOf(data, `فشل تحميل الإعدادات (${r.status})`));
      if (controller.signal.aborted || id !== settingsRequest.current) return;
      const { telegram_bot_token, telegram_bot_token_configured, token_configured, ...safeSettings } = data;
      const safe = { ...DEFAULT_SETTINGS, ...safeSettings, telegram_bot_token: "", telegram_bot_token_configured: Boolean(telegram_bot_token_configured ?? token_configured ?? telegram_bot_token) };
      cacheSet("settings", session, safe); setSettings(safe);
    } catch (e) { if (e?.name !== "AbortError" && id === settingsRequest.current) setLoadErrors((errors) => ({ ...errors, settings: e?.message || "تعذّر تحميل الإعدادات" })); }
    finally { if (id === settingsRequest.current) setSettingsLoading(false); }
  }, [authFetch, can, session]);

  useEffect(() => {
    const timer = tab === "users" ? window.setTimeout(() => loadUsers(query), query ? 220 : 0) : null;
    if (tab === "dashboard") loadStats();
    if (tab === "settings") loadSettings();
    return () => { if (timer !== null) window.clearTimeout(timer); if (tab === "users") usersAbort.current?.abort(); if (tab === "dashboard") statsAbort.current?.abort(); if (tab === "settings") settingsAbort.current?.abort(); };
  }, [tab, query, loadUsers, loadStats, loadSettings]);

  const filtered = useMemo(() => {
    const next = users.filter((u) => userStatus === "all" || (u.status || "active") === userStatus);
    return next.sort((a, b) => userSort === "balance" ? Number(b.token_balance || 0) - Number(a.token_balance || 0) : String(b.last_login || b.registered_at || "").localeCompare(String(a.last_login || a.registered_at || "")));
  }, [users, userSort, userStatus]);

  const act = async (path, method = "POST", body) => {
    setActionError("");
    try { const r = await authFetch(path, { method, body: body ? JSON.stringify(body) : undefined }); const d = await r.json().catch(() => ({})); if (!r.ok) { const message = detailOf(d, `فشلت العملية (${r.status})`); setActionError(message); toast.error(translateAdminError(message, t)); return null; } return d; }
    catch (e) { const message = e?.message || "خطأ في الشبكة"; setActionError(message); toast.error(translateAdminError(message, t)); return null; }
  };
  const refreshUsers = () => loadUsers(query, { force: true });
  const onResetPassword = async (u) => { const d = await act(`/admin/users/${u._id}/reset-password`); if (d?.temp_password) setPwResult({ user: u.username, temp: d.temp_password }); };
  const onResetRecovery = async (u) => { const d = await act(`/admin/users/${u._id}/reset-recovery`); if (d?.new_recovery_code) setRecResult({ user: u.username, code: d.new_recovery_code }); };
  const onSuspend = async (u) => { if (await act(`/admin/users/${u._id}/status`, "POST", { status: "suspended" })) { toast.success(t("معلّق")); refreshUsers(); } };
  const onActivate = async (u) => { if (await act(`/admin/users/${u._id}/status`, "POST", { status: "active" })) { toast.success(t("مفعّل")); refreshUsers(); } };
  const onDelete = async (u) => { if (!window.confirm(t("حذف {username}؟", { username: u.username }))) return; if (await act(`/admin/users/${u._id}`, "DELETE")) { toast.success(t("محذوف")); refreshUsers(); } };
  const onResetUsage = async (u) => { if (await act(`/admin/users/${u._id}/reset-usage`, "POST")) { toast.success(t("تم تصفير الاستخدام")); refreshUsers(); } };
  const onAddTokens = async (u) => { const value = window.prompt(t("إضافة توكنات إلى {username}:", { username: u.username }), "1000000"); const n = parseInt(value, 10); if (!n || n <= 0) return; if (await act("/admin/tokens/add", "POST", { user_id: u._id, amount: n, reason: "admin_add" })) { toast.success(t("تمت إضافة {count} توكن", { count: formatNumber(n) })); refreshUsers(); } };
  const onDeductTokens = async (u) => { const value = window.prompt(t("خصم توكنات من {username}:", { username: u.username }), "100000"); const n = parseInt(value, 10); if (!n || n <= 0) return; if (await act("/admin/tokens/deduct", "POST", { user_id: u._id, amount: n, reason: "admin_deduct" })) { toast.success(t("تم خصم {count} توكن", { count: formatNumber(n) })); refreshUsers(); } };
  const onSetTokens = async (u) => { const value = window.prompt(t("ضبط رصيد {username}:", { username: u.username }), String(u.token_balance || 0)); const n = parseInt(value, 10); if (Number.isNaN(n) || n < 0) return; if (await act("/admin/tokens/set", "POST", { user_id: u._id, balance: n })) { toast.success(t("الرصيد = {count}", { count: formatNumber(n) })); refreshUsers(); } };
  const onResetTokens = async (u) => { if (!window.confirm(t("إعادة رصيد {username} إلى 0؟", { username: u.username }))) return; if (await act("/admin/tokens/reset", "POST", { user_id: u._id, balance: 0 })) { toast.success(t("تم تصفير الرصيد")); refreshUsers(); } };
  const onTgVerify = async (u) => { if (await act(`/admin/users/${u._id}/telegram/verify`)) { toast.success(t("تم توثيق Telegram إجباريًا")); refreshUsers(); } };
  const onTgUnlink = async (u) => { if (!window.confirm(t("فصل Telegram عن {username}؟", { username: u.username }))) return; if (await act(`/admin/users/${u._id}/telegram/unlink`)) { toast.success(t("تم فصل Telegram")); refreshUsers(); } };

  const onSaveSettings = async () => {
    setSavingSettings(true); setActionError("");
    try {
      const payload = { ...settings }; delete payload.telegram_bot_token_configured; delete payload.token_configured; if (!payload.telegram_bot_token?.trim()) delete payload.telegram_bot_token;
      const r = await authFetch("/admin/settings", { method: "POST", body: JSON.stringify(payload) }); const data = await r.json().catch(() => ({}));
      if (!r.ok) { const message = detailOf(data, `فشل الحفظ (${r.status})`); setActionError(message); toast.error(translateAdminError(message, t)); return; }
      const next = { ...settings, telegram_bot_token: "", telegram_bot_token_configured: settings.telegram_bot_token?.trim() ? true : settings.telegram_bot_token_configured }; cacheSet("settings", session, next); setSettings(next); toast.success(t("تم حفظ الإعدادات"));
    } catch (e) { setActionError(e?.message || "خطأ في الشبكة"); toast.error(translateAdminError(e?.message || "خطأ في الشبكة", t)); }
    finally { setSavingSettings(false); }
  };
  const onTestTelegram = async () => { try { const r = await authFetch("/admin/telegram/test", { method: "POST", body: JSON.stringify({ text: "🧪 Test from rsvx7-ai admin" }) }); const d = await r.json().catch(() => ({})); if (r.ok && d?.ok) toast.success(t("تم إرسال اختبار Telegram")); else { const message = detailOf(d, "فشل الاختبار — تحقّق من التوكن وchat_id"); setActionError(message); toast.error(message); } } catch (e) { setActionError(e?.message || "خطأ في الشبكة"); toast.error(translateAdminError(e?.message || "خطأ في الشبكة", t)); } };
  const onBroadcast = async () => { if (!broadcast.trim()) return; try { const r = await authFetch("/admin/telegram/broadcast", { method: "POST", body: JSON.stringify({ text: broadcast.trim() }) }); const d = await r.json().catch(() => ({})); if (r.ok && d?.ok) { toast.success(t("تم إرسال البث")); setBroadcast(""); } else { const message = detailOf(d, "فشل"); setActionError(message); toast.error(message); } } catch (e) { setActionError(e?.message || "خطأ في الشبكة"); toast.error(translateAdminError(e?.message || "خطأ في الشبكة", t)); } };

  const tabActions = <div className="admin-inline-actions"><LanguageSwitcher /><ActionButton tone="ghost" onClick={() => { if (tab === "users") refreshUsers(); if (tab === "dashboard") loadStats({ force: true }); if (tab === "settings") loadSettings({ force: true }); }} loading={loading || statsLoading || settingsLoading} aria-label={t("تحديث الصفحة الحالية")}><RefreshCw size={16} /> {t("تحديث")}</ActionButton><ActionButton tone="ghost" onClick={onExit} data-testid="admin-back-btn"><ArrowLeft size={16} /> {t("العودة للمحادثة")}</ActionButton><ActionButton tone="ghost" onClick={logout} data-testid="admin-logout-btn"><LogOut size={16} /> {t("تسجيل الخروج")}</ActionButton></div>;

  return <div className="admin-page" dir={dir}><PageShell className="admin-shell"><PageHeader eyebrow={t("مساحة العمل · الإدارة")} title={t("لوحة إدارة rsvx7")} description={<span>{t("جلسة")} <span dir="ltr" className="admin-code text-brand-400">{user?.username || "—"}</span> · {t("الصلاحيات تُحترم من الخادم")}</span>} actions={tabActions} /><div className="admin-body"><aside className="admin-sidebar" aria-label={t("تنقل الإدارة")}><div className="admin-nav-label">{t("الأقسام")}</div>{TAB_DEFINITIONS.map(({ value, permission, label, icon: Icon }) => can(permission) && <button type="button" key={value} value={value} onClick={() => setTab(value)} role="tab" aria-selected={tab === value} data-testid={`tab-${value}`} className="admin-tab"><Icon size={17} aria-hidden="true" /><span>{t(label)}</span>{value === "users" && users.length > 0 && <span className="admin-tab-count">{formatNumber(users.length)}</span>}</button>)}</aside><div className="admin-main" dir={dir} role="tabpanel" aria-label={t(TAB_DEFINITIONS.find((item) => item.value === tab)?.label || "الإدارة")}>{actionError && <StatusNote tone="error" onRetry={() => setActionError("")}>{translateAdminError(actionError, t)}</StatusNote>}

  {allowedTabs.length === 0 && <EmptyState title={t("لا توجد صلاحيات إدارة لهذا الحساب")} description={t("اطلب من مالك الموقع منحك الصلاحيات المناسبة، أو عد إلى المحادثة.")} action={<ActionButton tone="ghost" onClick={onExit}>{t("العودة للمحادثة")}</ActionButton>} />}

  {tab === "dashboard" && can("dashboard") && <section className="admin-section"><PageHeader eyebrow={t("المؤشرات · قراءة فقط")} title={t("ملخّص النشاط")} description={t("لا تُطلب هذه البيانات إلا عند فتح تبويب لوحة المؤشرات، مع صلاحية dashboard.")} actions={null} />{loadErrors.stats && <StatusNote tone="error" onRetry={() => loadStats({ force: true })}>{translateAdminError(loadErrors.stats, t)}</StatusNote>}{statsLoading && !stats && <LoadingState label={t("جارٍ تحميل المؤشرات…")} />}{!statsLoading && !stats && !loadErrors.stats && <EmptyState title={t("لا توجد مؤشرات متاحة")} description={t("لم يعرض الخادم بيانات لوحة المؤشرات.")} />}{stats && <div className="admin-metrics"><MetricCard label={t("إجمالي المستخدمين")} value={formatNumber(stats.total_users)} icon={Users} /><MetricCard label={t("نشطون")} value={formatNumber(stats.active_users)} icon={Activity} /><MetricCard label={t("موقوفون")} value={formatNumber(stats.suspended_users)} icon={Ban} /><MetricCard label={t("مميز")} value={formatNumber(stats.premium_users)} icon={Crown} /></div>}</section>}

  {tab === "users" && can("users") && <section className="admin-section"><PageHeader eyebrow={t("الوصول · الحسابات")} title={t("المستخدمون")} description={t("تُحدَّث النتائج بعد توقف الكتابة، ثم نفّذ إجراءات الحساب من القائمة. لا تُحمّل بقية جداول الإدارة مع هذه الصفحة.")} actions={<ActionButton onClick={() => loadUsers(query, { force: true })} loading={loading}>{t("تحديث المستخدمين")}</ActionButton>} />{loadErrors.users && <StatusNote tone="error" onRetry={() => loadUsers(query, { force: true })}>{translateAdminError(loadErrors.users, t)}</StatusNote>}<Panel className="admin-content-card" style={{ padding: "16px" }}><div className="admin-toolbar"><div className="admin-toolbar-group" style={{ flex: "1 1 400px" }}><label className="ds-field" style={{ flex: "1 1 300px" }}><span className="sr-only">{t("البحث عن مستخدم")}</span><Input value={query} onChange={(e) => setQuery(e.target.value)} onKeyDown={(e) => { if (e.key === "Enter") loadUsers(query, { force: true }); }} placeholder={t("ابحث باسم المستخدم أو Telegram…")} data-testid="admin-search-input" className="ds-input" /></label><select data-testid="admin-users-status-filter" value={userStatus} onChange={(e) => setUserStatus(e.target.value)} className="ds-input" aria-label={t("تصفية حالة المستخدم")}><option value="all">{t("كل الحالات")}</option><option value="active">{t("نشط")}</option><option value="suspended">{t("موقوف")}</option></select><select data-testid="admin-users-sort" value={userSort} onChange={(e) => setUserSort(e.target.value)} className="ds-input" aria-label={t("ترتيب المستخدمين")}><option value="recent">{t("الأحدث دخولًا")}</option><option value="balance">{t("الأعلى رصيدًا")}</option></select></div><p className="admin-soft-note">{t("{count} مستخدم", { count: formatNumber(filtered.length) })}</p></div><div className="ds-table-wrap admin-table-panel"><div className="admin-table-scroll"><table className="ds-table" data-testid="admin-users-table"><thead><tr><th>{t("المستخدم")}</th><th>{t("الرصيد")}</th><th>{t("التوكن المستخدم")}</th><th>{t("التسجيل")}</th><th>{t("آخر دخول")}</th><th>{t("الحالة")}</th><th>{t("إجراءات")}</th></tr></thead><tbody>{loading && <tr><td colSpan={7}><LoadingState label={t("جارٍ تحميل المستخدمين…")} compact /></td></tr>}{!loading && !loadErrors.users && filtered.length === 0 && <tr><td colSpan={7} className="admin-table-empty"><EmptyState title={t("لا يوجد مستخدمون مطابقون")} description={t("جرّب تعديل البحث أو الفلاتر.")} /></td></tr>}{!loading && !loadErrors.users && filtered.map((u) => { const bal = u.token_balance; const isStaff = u.plan === "admin"; return <tr key={u._id} data-testid={`admin-user-row-${u.username}`}><td><div className="font-medium text-white flex items-center gap-2"><span dir="ltr" className="admin-code">{u.username}</span>{u.is_owner && <span className="ds-badge ds-badge-warning">{t("المالك")}</span>}{isAdmin(u) && !u.is_owner && <span className="ds-badge ds-badge-brand">{t(roleLabelSource(u.role))}</span>}</div></td><td data-testid={`admin-user-balance-${u.username}`}><span className="inline-flex items-center gap-1.5 tabular-nums"><Coins className="w-3.5 h-3.5 text-brand-400" />{isStaff || bal === -1 ? "∞" : formatNumber(bal ?? 0)}</span></td><td className="text-zinc-300 tabular-nums text-xs">{formatNumber(u.total_used_tokens || 0)}</td><td className="text-zinc-400 text-xs">{fmt(u.registered_at, formatDate)}</td><td className="text-zinc-400 text-xs">{fmt(u.last_login, formatDate)}</td><td>{u.status === "suspended" ? <span className="ds-badge ds-badge-danger">{t("موقوف")}</span> : <span className="ds-badge ds-badge-success">{t("نشط")}</span>}</td><td className="text-right"><DropdownMenu><DropdownMenuTrigger asChild><button type="button" data-testid={`admin-row-menu-${u.username}`} className="admin-icon-button p-1.5 rounded hover:bg-white/[0.06]" aria-label={t("إجراءات {username}", { username: u.username })}><MoreHorizontal className="w-4 h-4" /></button></DropdownMenuTrigger><DropdownMenuContent align="end" className="w-60 bg-bg-surface border-soft text-white">{can("payments") && <DropdownMenuItem onClick={() => setSubTarget(u)} data-testid={`row-assign-${u.username}`}><Sparkles className="w-4 h-4 mr-2" /> {t("إضافة حزمة رصيد")}</DropdownMenuItem>}<DropdownMenuSeparator className="bg-white/10" />{can("payments") && <DropdownMenuItem onClick={() => onAddTokens(u)} data-testid={`row-add-tokens-${u.username}`}><Coins className="w-4 h-4 mr-2" /> {t("إضافة توكن مخصص")}</DropdownMenuItem>}{can("payments") && <DropdownMenuItem onClick={() => onDeductTokens(u)} data-testid={`row-deduct-tokens-${u.username}`}><Coins className="w-4 h-4 mr-2" /> {t("خصم توكن")}</DropdownMenuItem>}{can("payments") && <DropdownMenuItem onClick={() => onSetTokens(u)} data-testid={`row-set-tokens-${u.username}`}><Coins className="w-4 h-4 mr-2" /> {t("ضبط الرصيد")}</DropdownMenuItem>}{can("payments") && <DropdownMenuItem onClick={() => onResetTokens(u)} data-testid={`row-reset-tokens-${u.username}`} className="text-red-400 focus:text-red-300"><Coins className="w-4 h-4 mr-2" /> {t("تصفير الرصيد")}</DropdownMenuItem>}<DropdownMenuItem onClick={() => onResetUsage(u)} data-testid={`row-reset-usage-${u.username}`}><RotateCcw className="w-4 h-4 mr-2" /> {t("تصفير الاستخدام")}</DropdownMenuItem><DropdownMenuSeparator className="bg-white/10" /><DropdownMenuItem onClick={() => onResetPassword(u)} data-testid={`row-reset-pw-${u.username}`}><KeyRound className="w-4 h-4 mr-2" /> {t("إعادة كلمة المرور")}</DropdownMenuItem><DropdownMenuItem onClick={() => onResetRecovery(u)} data-testid={`row-reset-rec-${u.username}`}><RotateCcw className="w-4 h-4 mr-2" /> {t("إعادة رمز الاسترداد")}</DropdownMenuItem><DropdownMenuSeparator className="bg-white/10" />{can("telegram") && <DropdownMenuItem onClick={() => onTgVerify(u)} data-testid={`row-tg-verify-${u.username}`}><Send className="w-4 h-4 mr-2" /> {t("توثيق Telegram")}</DropdownMenuItem>}{can("telegram") && <DropdownMenuItem onClick={() => onTgUnlink(u)} data-testid={`row-tg-unlink-${u.username}`}><Send className="w-4 h-4 mr-2 rotate-180" /> {t("فصل Telegram")}</DropdownMenuItem>}<DropdownMenuSeparator className="bg-white/10" />{u.status === "suspended" ? <DropdownMenuItem onClick={() => onActivate(u)} data-testid={`row-activate-${u.username}`}><CheckCircle2 className="w-4 h-4 mr-2" /> {t("تفعيل")}</DropdownMenuItem> : !u.is_owner && <DropdownMenuItem onClick={() => onSuspend(u)} data-testid={`row-suspend-${u.username}`}><Ban className="w-4 h-4 mr-2" /> {t("تعليق")}</DropdownMenuItem>}{!isAdmin(u) && !u.is_owner && <DropdownMenuItem onClick={() => onDelete(u)} data-testid={`row-delete-${u.username}`} className="text-red-400 focus:text-red-300"><Trash2 className="w-4 h-4 mr-2" /> {t("حذف المستخدم")}</DropdownMenuItem>}</DropdownMenuContent></DropdownMenu></td></tr>; })}</tbody></table></div></div></Panel></section>}

  {tab === "coupons" && can("coupons") && <AdminCoupons />}
  {tab === "website_admins" && can("website_admins") && <AdminAdmins />}
  {tab === "telegram" && can("telegram") && <AdminTelegramVerify />}
  {tab === "servers" && user?.role === "super_admin" && <AdminVPS />}
  {tab === "ai_models" && can("ai_models") && <AdminAISettings />}

  {tab === "settings" && can("settings") && <section className="admin-section space-y-4"><PageHeader eyebrow={t("إعدادات Telegram")} title={t("إعدادات الإشعارات")} description={t("التوكن للكتابة فقط: يرسل الخادم علامة الإعداد فقط، والإدخال الفارغ يحافظ على القيمة الحالية.")} actions={null} />{loadErrors.settings && <StatusNote tone="error" onRetry={() => loadSettings({ force: true })}>{translateAdminError(loadErrors.settings, t)}</StatusNote>}{settingsLoading && <LoadingState label={t("جارٍ تحميل الإعدادات…")} />}<Panel className="admin-content-card" style={{ padding: "20px" }}><form className="ds-form-stack" onSubmit={(e) => { e.preventDefault(); onSaveSettings(); }}><div className="ds-field"><Label>{t("رمز البوت")} <span className="admin-soft-note">{t("(اتركه فارغًا للإبقاء على الحالي)")}</span></Label><Input type="password" value={settings.telegram_bot_token || ""} onChange={(e) => setSettings((s) => ({ ...s, telegram_bot_token: e.target.value }))} placeholder={settings.telegram_bot_token_configured ? t("مهيأ · الفراغ يُبقي الحالي") : t("أدخل التوكن الجديد")} data-testid="settings-tg-token" className="ds-input admin-code" />{settings.telegram_bot_token_configured && <p className="text-xs text-emerald-400">{t("التوكن مهيأ. لا تُعرض قيمته الحالية أبدًا.")}</p>}</div><div className="admin-form-grid"><div className="ds-field"><Label>{t("معرّف الدردشة")}</Label><Input value={settings.telegram_chat_id || ""} onChange={(e) => setSettings((s) => ({ ...s, telegram_chat_id: e.target.value }))} placeholder={t("-1001234567890 أو 123456789")} data-testid="settings-tg-chat" className="ds-input admin-code" /></div><div className="ds-field"><Label>{t("رابط Telegram العام")}</Label><Input value={settings.telegram_link || ""} onChange={(e) => setSettings((s) => ({ ...s, telegram_link: e.target.value }))} placeholder="https://t.me/your_channel" data-testid="settings-tg-link" className="ds-input admin-code" /></div><div className="ds-field"><Label>{t("اسم المستخدم للبوت")}</Label><Input value={settings.telegram_bot_username || ""} onChange={(e) => setSettings((s) => ({ ...s, telegram_bot_username: e.target.value.replace(/^@/, "") }))} placeholder="Rsvx7_ai_bot" data-testid="settings-tg-bot-username" className="ds-input admin-code" /></div></div><label className="flex items-start justify-between gap-3 pt-2"><span><span className="text-sm text-white">{t("إشعار المدير عند كل تسجيل دخول")}</span><span className="admin-soft-note block mt-1">{t("يرسل الخادم إشعارًا إلى غرفة المدير عند تسجيل المستخدم.")}</span></span><Switch checked={!!settings.notify_on_login} onCheckedChange={(v) => setSettings((s) => ({ ...s, notify_on_login: v }))} data-testid="settings-notify-on-login" /></label><div className="admin-inline-actions"><Button type="submit" disabled={savingSettings || settingsLoading} data-testid="settings-save-btn" className="bg-brand-500 hover:bg-brand-600 text-white">{savingSettings ? t("جارٍ الحفظ…") : t("حفظ الإعدادات")}</Button><Button type="button" onClick={onTestTelegram} disabled={!can("telegram")} title={!can("telegram") ? t("تتطلب العملية صلاحية Telegram") : undefined} data-testid="settings-test-btn" variant="ghost" className="border border-soft text-zinc-200"><Send className="w-4 h-4 mr-2" /> {t("إرسال رسالة اختبار")}</Button></div></form></Panel><Panel className="admin-content-card" style={{ padding: "20px" }}><div className="ds-field"><Label>{t("رسالة بث")}</Label><p className="admin-soft-note">{t("أرسل رسالة مخصصة إلى غرفة Telegram المهيأة.")}</p><textarea dir="auto" value={broadcast} onChange={(e) => setBroadcast(e.target.value)} rows={3} data-testid="broadcast-input" placeholder={t("اكتب رسالتك…")} className="ds-textarea" /><Button type="button" onClick={onBroadcast} disabled={!can("telegram") || !broadcast.trim()} title={!can("telegram") ? t("تتطلب العملية صلاحية Telegram") : undefined} data-testid="broadcast-send-btn" className="bg-brand-500 hover:bg-brand-600 text-white"><Send className="w-4 h-4 mr-2" /> {t("إرسال البث")}</Button></div></Panel></section>}
  </div></div></PageShell>
  <AssignSubscriptionDialog open={!!subTarget && can("payments")} target={subTarget} onClose={() => setSubTarget(null)} onSaved={() => { setSubTarget(null); loadUsers(query, { force: true }); loadStats({ force: true }); }} authFetch={authFetch} />
  <Dialog open={!!pwResult} onOpenChange={(v) => !v && setPwResult(null)}><DialogContent className="bg-bg-surface border-soft text-white" dir={dir}><DialogHeader><DialogTitle>{t("تم إنشاء كلمة مرور مؤقتة")}</DialogTitle><DialogDescription className="text-zinc-400">{t("شاركها مع {username}. سيُطلب تغييرها عند الدخول التالي.", { username: pwResult?.user || "" })}</DialogDescription></DialogHeader><div className="bg-bg-main border border-brand-500/40 rounded-xl px-4 py-3 admin-code text-lg text-brand-400 text-center tracking-widest" data-testid="temp-pw-display">{pwResult?.temp}</div><DialogFooter><Button onClick={async () => { try { await copyToClipboard(pwResult?.temp || ""); toast.success(t("تم النسخ")); } catch { toast.error(t("تعذّر النسخ")); } }} variant="ghost" className="bg-bg-main border border-soft text-zinc-200"><Copy className="w-4 h-4 mr-2" /> {t("نسخ")}</Button><Button onClick={() => setPwResult(null)} className="bg-brand-500 hover:bg-brand-600">{t("تم")}</Button></DialogFooter></DialogContent></Dialog>
  <Dialog open={!!recResult} onOpenChange={(v) => !v && setRecResult(null)}><DialogContent className="bg-bg-surface border-soft text-white" dir={dir}><DialogHeader><DialogTitle>{t("رمز استرداد جديد")}</DialogTitle><DialogDescription className="text-zinc-400">{t("شارك الرمز مع {username}. لم يعد الرمز القديم صالحًا.", { username: recResult?.user || "" })}</DialogDescription></DialogHeader><div className="bg-bg-main border border-brand-500/40 rounded-xl px-4 py-3 admin-code text-lg text-brand-400 text-center tracking-widest" data-testid="new-rec-display">{recResult?.code}</div><DialogFooter><Button onClick={async () => { try { await copyToClipboard(recResult?.code || ""); toast.success(t("تم النسخ")); } catch { toast.error(t("تعذّر النسخ")); } }} variant="ghost" className="bg-bg-main border border-soft text-zinc-200"><Copy className="w-4 h-4 mr-2" /> {t("نسخ")}</Button><Button onClick={() => setRecResult(null)} className="bg-brand-500 hover:bg-brand-600">{t("تم")}</Button></DialogFooter></DialogContent></Dialog>
  </div>;
}

function AssignSubscriptionDialog({ open, target, onClose, onSaved, authFetch }) {
  const { t, dir, formatNumber } = useI18n("admin");
  const [plan, setPlan] = useState("basic"); const [busy, setBusy] = useState(false);
  const submit = async () => { if (!target) return; setBusy(true); try { const r = await authFetch(`/admin/users/${target._id}/subscription`, { method: "POST", body: JSON.stringify({ plan, days: 0 }) }); const d = await r.json().catch(() => ({})); if (!r.ok) { toast.error(translateAdminError(detailOf(d, `فشلت العملية (${r.status})`), t)); return; } toast.success(t("تمت إضافة {added} توكن · الرصيد الجديد {balance}", { added: formatNumber(d.added || 0), balance: formatNumber(d.token_balance || 0) })); onSaved?.(); } catch (e) { toast.error(t(e?.message || "خطأ في الشبكة")); } finally { setBusy(false); } };
  return <Dialog open={open} onOpenChange={(v) => !v && onClose?.()}><DialogContent className="bg-bg-surface border-soft text-white" dir={dir}><DialogHeader><DialogTitle>{t("إضافة حزمة رصيد")}</DialogTitle><DialogDescription className="text-zinc-400">{t("تُضاف التوكنات فوق الرصيد الحالي بلا انتهاء أو اشتراك.")}<br />{t("المستخدم: ")}<span dir="ltr" className="text-brand-400 font-medium">{target?.username}</span></DialogDescription></DialogHeader><div className="ds-field"><Label>{t("حزمة الرصيد")}</Label><Select value={plan} onValueChange={setPlan}><SelectTrigger data-testid="sub-plan-select" className="ds-input mt-1"><SelectValue /></SelectTrigger><SelectContent className="bg-bg-surface border-soft text-white">{PLAN_OPTIONS.map((p) => <SelectItem key={p.id} value={p.id}>{t(p.label)}</SelectItem>)}</SelectContent></Select></div><DialogFooter><Button onClick={onClose} variant="ghost" className="text-zinc-300">{t("إلغاء")}</Button><Button onClick={submit} disabled={busy} data-testid="sub-confirm-btn" className="bg-brand-500 hover:bg-brand-600">{busy ? t("جارٍ الإضافة…") : t("إضافة التوكن")}</Button></DialogFooter></DialogContent></Dialog>;
}
