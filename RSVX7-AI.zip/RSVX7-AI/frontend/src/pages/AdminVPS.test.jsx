import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import AdminVPS from './AdminVPS';

const mockAuthFetch = jest.fn();
jest.mock('@/context/AuthContext', () => ({ useAuth: () => ({ authFetch: mockAuthFetch }) }));
jest.mock('@/components/ui/button', () => ({ Button: ({ variant, ...props }) => <button {...props} /> }));
const reply = (data, ok = true) => ({ ok, json: async () => data });
const initial = { revision: 0, host: '', port: 22, username: 'root', authMethod: 'password', fingerprint: '', siteUrl: '', installPath: '/opt/rsvx7', provider: 'openrouter', model: 'provider/model', credentialsConfigured: false };
const configured = { ...initial, revision: 1, host: 'vps.example.com', fingerprint: 'SHA256:' + 'A'.repeat(43), siteUrl: 'https://app.example.com', credentialsConfigured: true };
let container, root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  mockAuthFetch.mockReset();
  container = document.createElement('div'); document.body.appendChild(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); jest.useRealTimers(); });
const element = id => container.querySelector(`[data-testid="vps-${id}"]`);
const mount = async () => { await act(async () => root.render(<AdminVPS />)); };
const click = async id => { await act(async () => element(id).click()); };
async function change(id, value) {
  await act(async () => {
    const input = element(id);
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, value);
    input.dispatchEvent(new Event('input', { bubbles: true }));
  });
}

test('owner must trust a fingerprint before saving; saved credentials are write-only', async () => {
  mockAuthFetch.mockImplementation(async (path, options) => {
    if (path.endsWith('/host-key')) return reply({ fingerprint: configured.fingerprint });
    return reply(options?.method === 'PUT' ? configured : initial);
  });
  await mount();
  await change('host', configured.host); await change('siteUrl', configured.siteUrl); await change('password', 'fixture-ssh-password');
  expect(element('save').disabled).toBe(true);
  await click('scan');
  expect(element('fingerprint').value).toBe(configured.fingerprint);
  expect(element('save').disabled).toBe(true);
  await click('trust'); await click('save');
  const saved = mockAuthFetch.mock.calls.find(([, options]) => options?.method === 'PUT');
  expect(JSON.parse(saved[1].body).password).toBe('fixture-ssh-password');
  expect(element('password').value).toBe('');
  expect(container.textContent).not.toContain('fixture-ssh-password');
  expect(element('test').disabled).toBe(false);
});

test('deployment needs a successful connection test and locks controls while running', async () => {
  mockAuthFetch.mockImplementation(async path => reply(path.endsWith('/test') ? { ready: true, revision: 1 }
    : path.endsWith('/deploy') ? { job: { id: 'job', status: 'running', message: 'جارٍ البناء' } } : configured));
  await mount();
  expect(element('deploy').disabled).toBe(true);
  await click('test'); expect(element('deploy').disabled).toBe(false);
  await click('deploy');
  expect(element('deploy').disabled).toBe(true);
  expect(element('host').disabled).toBe(true);
  expect(container.textContent).toContain('جارٍ البناء');
  expect(container.querySelector('iframe')).toBeNull();
});

test('status polling preserves unsaved fields and prevents deploying stale edits', async () => {
  jest.useFakeTimers();
  mockAuthFetch.mockResolvedValue(reply({ ...configured, tested: { ready: true, revision: 1 } }));
  await mount(); await change('siteUrl', 'https://edited.example.com');
  mockAuthFetch.mockResolvedValue(reply({ ...configured, revision: 2 }));
  await act(async () => jest.advanceTimersByTime(3000));
  expect(element('siteUrl').value).toBe('https://edited.example.com');
  expect(element('test').disabled).toBe(true);
  expect(element('deploy').disabled).toBe(true);
});

test('SSH errors are visible and do not leave actions stuck', async () => {
  mockAuthFetch.mockImplementation(async path => path.endsWith('/test')
    ? reply({ detail: 'بصمة الخادم لا تطابق المحفوظة' }, false) : reply(configured));
  await mount(); await click('test');
  expect(container.textContent).toContain('بصمة الخادم لا تطابق المحفوظة');
  expect(element('test').disabled).toBe(false);
  expect(element('deploy').disabled).toBe(true);
});

test('a failed deployment can be rechecked without starting another build', async () => {
  jest.useFakeTimers();
  const failed = { ...configured, job: { id: 'a'.repeat(32), status: 'failed', message: 'الرابط غير جاهز' } };
  mockAuthFetch.mockImplementation(async path => reply(path.endsWith('/health')
    ? { job: { id: 'b'.repeat(32), releaseId: failed.job.id, mode: 'health', status: 'running', message: 'فحص الخدمات والرابط' } } : failed));
  await mount();
  expect(element('health').disabled).toBe(false);
  await click('health');
  expect(element('health').disabled).toBe(true);
  expect(mockAuthFetch.mock.calls.some(([path]) => path.endsWith('/deploy'))).toBe(false);
  const healthy = { ...configured, job: { status: 'completed', url: configured.siteUrl, message: 'تم التحقق من تشغيل المنصة' },
    health: { checks: [{ id: 'release', status: 'passed', code: 'ready' }, { id: 'model', status: 'failed', code: 'missing_key' }] } };
  mockAuthFetch.mockResolvedValue(reply(healthy));
  await act(async () => jest.advanceTimersByTime(3000));
  expect(container.querySelector('a').href).toBe(configured.siteUrl + '/');
  expect(element('checks').textContent).toContain('نسخة التطبيق');
  expect(element('checks').textContent).toContain('أضف مفتاح المزوّد');
});

test('unsaved server changes disable rechecking the previous deployment', async () => {
  mockAuthFetch.mockResolvedValue(reply({ ...configured, job: { id: 'a'.repeat(32), status: 'completed', url: configured.siteUrl } }));
  await mount(); await change('host', 'different.example.com');
  expect(element('health').disabled).toBe(true);
});
