import React, { useEffect, useState } from "react";
import { useCallback } from "react";
import { Copy, ExternalLink, Eye, EyeOff, Gift, ShieldAlert } from "lucide-react";
import { useAuth } from "@/context/AuthContext";
import { ActionButton, AuthShell, Panel, StatusNote } from "@/components/design/Primitives";
import { useI18n } from "@/i18n";
import "@/i18n/catalogs/auth";
import "@/components/auth-ui.css";

const BACKEND = process.env.REACT_APP_BACKEND_URL || "";

// Sniff `?ref=` from URL or hash on first mount; survives hash-based routing.
function readRefFromUrl() {
  try {
    const queryRef = new URLSearchParams(window.location.search).get("ref");
    if (queryRef) return queryRef;
    const hash = window.location.hash || "";
    const match = hash.match(/[?&]ref=([A-Z0-9]{8})/i);
    if (match) return match[1];
  } catch {
    // A malformed URL should never block registration.
  }
  return "";
}

function PasswordField({ value, onChange }) {
  const { t } = useI18n("auth");
  const [visible, setVisible] = useState(false);
  return (
    <div className="ds-field auth-ui-field">
      <label className="auth-ui-label" htmlFor="reg-password">{t("كلمة المرور")} <span className="auth-ui-hint">{t("6 أحرف على الأقل")}</span></label>
      <div className="auth-ui-input-wrap has-toggle">
        <input id="reg-password" data-testid="reg-password" className="ds-input auth-ui-input" type={visible ? "text" : "password"} value={value} onChange={onChange} autoComplete="new-password" placeholder={t("كلمة المرور")} required minLength={6} />
        <button type="button" className="auth-ui-toggle" onClick={() => setVisible((current) => !current)} aria-label={visible ? t("إخفاء كلمة المرور") : t("إظهار كلمة المرور")} aria-pressed={visible} data-testid="reg-password-toggle">
          {visible ? <EyeOff size={17} aria-hidden="true" /> : <Eye size={17} aria-hidden="true" />}
        </button>
      </div>
    </div>
  );
}

export default function Register({ onSwitch, onSuccess }) {
  const { register, activateSession } = useAuth();
  const { t, dir, formatNumber } = useI18n("auth");
  const [u, setU] = useState("");
  const [p, setP] = useState("");
  const [busy, setBusy] = useState(false);
  const [ref, setRef] = useState("");
  const [refInfo, setRefInfo] = useState(null);
  const [result, setResult] = useState(null);
  const [link, setLink] = useState(null);
  const [linkError, setLinkError] = useState("");
  const [preparingLink, setPreparingLink] = useState(false);
  const [continuing, setContinuing] = useState(false);
  const [error, setError] = useState("");
  const [copyState, setCopyState] = useState("");

  const prepareLink = useCallback(async (token) => {
    setPreparingLink(true);
    setLinkError("");
    setLink(null);
    try {
      const response = await fetch(`${BACKEND}/api/auth/telegram/start`, {
        method: "POST",
        credentials: "include",
        headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
        body: "{}",
      });
      const data = await response.json().catch(() => ({}));
      if (!response.ok) throw new Error(typeof data.detail === "string" ? data.detail : data.detail?.message || t("تعذّر تجهيز رابط الربط."));
      setLink(data);
    } catch (requestError) {
      setLinkError(requestError?.message || t("تعذّر الاتصال. أعد المحاولة."));
    } finally {
      setPreparingLink(false);
    }
  }, [t]);

  useEffect(() => {
    const referral = readRefFromUrl();
    if (!referral) return undefined;
    setRef(referral.toUpperCase());
    const controller = typeof AbortController === "function" ? new AbortController() : null;
    let active = true;
    fetch(`${BACKEND}/api/referrals/lookup/${referral}`, controller ? { signal: controller.signal } : undefined)
      .then((response) => response.ok ? response.json() : null)
      .then((data) => { if (active && data) setRefInfo(data); })
      .catch(() => {});
    return () => {
      active = false;
      controller?.abort();
    };
  }, []);

  const submit = async (event) => {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const uname = u.trim().toLowerCase();
      if (uname.length < 3) throw new Error("اسم المستخدم يجب أن يتكون من 3 أحرف على الأقل.");
      if (!/^[a-z0-9._-]+$/i.test(uname)) throw new Error("اسم المستخدم يقبل الحروف والأرقام والنقاط والشرطات السفلية والواصلات فقط.");
      if (p.length < 6) throw new Error("كلمة المرور يجب أن تكون 6 أحرف على الأقل.");
      const data = await register(uname, p, ref || undefined);
      setResult({ token: data.token, recovery_code: data.recovery_code, telegram_required: data.telegram_required });
      if (data.telegram_required !== false) await prepareLink(data.token);
    } catch (submitError) {
      setError(submitError?.message || "تعذّر إنشاء الحساب.");
    } finally {
      setBusy(false);
    }
  };

  const continueToChat = async () => {
    setError("");
    setContinuing(true);
    try {
      const account = await activateSession(result?.token);
      if (!account) throw new Error("تعذّر تفعيل الجلسة. حاول تسجيل الدخول بحسابك الجديد.");
      onSuccess?.();
    } catch (activationError) {
      setError(activationError?.message || "تعذّر الدخول.");
    } finally {
      setContinuing(false);
    }
  };

  const copyRecoveryCode = async () => {
    setCopyState("");
    try {
      if (!navigator.clipboard?.writeText) throw new Error("clipboard unavailable");
      await navigator.clipboard.writeText(result.recovery_code);
      setCopyState("تم نسخ الرمز. احفظه في مكان آمن.");
    } catch {
      setCopyState("تعذّر النسخ. احفظ الرمز يدويًا.");
    }
  };

  if (result?.recovery_code) {
    const code = result.recovery_code;
    return (
      <AuthShell className="auth-ui-shell auth-ui-recovery-shell" title={t("احفظ رمز الاسترداد")} subtitle={t("سيظهر هذا الرمز مرة واحدة فقط، وهو طريقك لاستعادة الحساب عند نسيان كلمة المرور.")}>
        <Panel className="auth-ui-card auth-ui-recovery" dir={dir}>
          <ShieldAlert size={27} aria-hidden="true" />
          <p className="auth-ui-note">{t("لا تفقد الرمز. لن نعرضه مرة أخرى بعد مغادرة هذه الخطوة.")}</p>
          <div className="auth-ui-recovery-code" data-testid="recovery-code" dir="ltr">{code}</div>
          <ActionButton type="button" tone="ghost" onClick={copyRecoveryCode} data-testid="copy-recovery">
            <Copy size={16} aria-hidden="true" />
            {t("نسخ الرمز")}
          </ActionButton>
          {copyState && <p className={copyState.startsWith("تم") ? "auth-ui-success" : "auth-ui-error"} role={copyState.startsWith("تم") ? "status" : "alert"}>{t(copyState)}</p>}

          {result.telegram_required !== false && <div className="auth-ui-step" data-testid="register-telegram-step">
            <p className="auth-ui-section-label">{t("ربط حساب Telegram")}</p>
            {preparingLink && <p className="auth-ui-note" role="status">{t("جارٍ تجهيز رابطك الخاص…")}</p>}
            {link?.deep_link && (
              <a href={link.deep_link} target="_blank" rel="noopener noreferrer" data-testid="register-telegram-link" className="auth-ui-link-card" dir="ltr">
                <span className="auth-ui-link-card-copy"><strong>@{String(link.telegram_bot_username || t("بوت Telegram")).replace(/^@/, "")}</strong><span>{link.deep_link}</span></span>
                <ExternalLink size={16} aria-hidden="true" />
              </a>
            )}
            {link?.telegram_bot_configured === false && <p role="alert" className="auth-ui-warning">{t("البوت غير مهيّأ من الإدارة بعد؛ يجب ضبط مفتاح البوت واسم المستخدم قبل إكمال الربط.")}</p>}
            {linkError && <StatusNote tone="error" retryLabel={t("إعادة المحاولة")} onRetry={() => prepareLink(result.token)}> {t(linkError)} </StatusNote>}
            {!preparingLink && !link?.deep_link && <ActionButton type="button" tone="ghost" onClick={() => prepareLink(result.token)} data-testid="register-link-retry">{t("إعادة تجهيز الرابط")}</ActionButton>}
          </div>}
          {error && <StatusNote tone="error">{t(error)}</StatusNote>}
          <ActionButton type="button" tone="primary" loading={continuing} onClick={continueToChat} data-testid="recovery-done" className="auth-ui-submit">
            {continuing ? t("جارٍ الدخول…") : t(result.telegram_required === false ? "حفظت رمز الاسترداد — متابعة" : "حفظت رمز الاسترداد — متابعة الربط")}
          </ActionButton>
        </Panel>
      </AuthShell>
    );
  }

  return (
    <AuthShell
      className="auth-ui-shell auth-ui-register"
      title={t("أنشئ حسابك")}
      subtitle={t("ابدأ مساحة عملك. لا نحتاج إلى بريد إلكتروني، وستحصل على رصيد ترحيبي عند التسجيل.")}
      footer={<div className="auth-ui-link-row"><span>{t("لديك حساب بالفعل؟")}</span><button type="button" onClick={onSwitch} className="auth-ui-link" data-testid="link-login">{t("تسجيل الدخول")}</button></div>}
    >
      <Panel className="auth-ui-card" dir={dir}>
        {error && <StatusNote tone="error">{t(error)}</StatusNote>}
        {refInfo && <div className="auth-ui-referral" data-testid="reg-referrer-banner"><Gift size={17} aria-hidden="true" /><span>{t("دعوة من {username}", { username: refInfo.referrer_username })}<br /><span className="auth-ui-hint">{t("فعّل Telegram بعد التسجيل لفتح رصيد إضافي قدره {tokens} رمز.", { tokens: formatNumber(2500) })}</span></span></div>}
        <form onSubmit={submit} className="ds-form-stack auth-ui-form" noValidate>
          <div className="ds-field auth-ui-field">
            <label className="auth-ui-label" htmlFor="reg-username">{t("اسم المستخدم")}</label>
            <input id="reg-username" data-testid="reg-username" className="ds-input auth-ui-input" value={u} onChange={(event) => setU(event.target.value)} autoComplete="username" placeholder={t("اسم المستخدم")} dir="ltr" spellCheck="false" required minLength={3} />
            <span className="auth-ui-hint">{t("حروف وأرقام ونقاط وشرطات سفلية فقط.")}</span>
          </div>
          <PasswordField value={p} onChange={(event) => setP(event.target.value)} />
          {ref && !refInfo && <p className="auth-ui-note">{t("رمز الإحالة:")} <span className="auth-ui-code-block" dir="ltr">{ref}</span></p>}
          <ActionButton type="submit" loading={busy} tone="primary" data-testid="reg-submit" className="auth-ui-submit">
            {busy ? t("جارٍ إنشاء الحساب…") : t("إنشاء الحساب")}
          </ActionButton>
        </form>
      </Panel>
    </AuthShell>
  );
}
