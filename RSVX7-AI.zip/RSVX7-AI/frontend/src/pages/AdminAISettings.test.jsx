import React, { act } from "react";
import { createRoot } from "react-dom/client";
import AdminAISettings from "./AdminAISettings";
import { toast } from "sonner";

const mockAuthFetch = jest.fn();
let mockUser;
jest.mock("@/context/AuthContext", () => ({ useAuth: () => ({ authFetch: mockAuthFetch, user: mockUser }) }));
jest.mock("sonner", () => ({ toast: { success: jest.fn(), error: jest.fn() } }));
jest.mock("@/components/ui/button", () => ({ Button: (props) => require("react").createElement("button", props) }));
jest.mock("@/components/ui/input", () => ({ Input: (props) => require("react").createElement("input", props) }));
jest.mock("@/components/ui/label", () => ({ Label: (props) => require("react").createElement("label", props) }));
jest.mock("@/components/ui/badge", () => ({ Badge: (props) => require("react").createElement("span", props) }));

const initial = { model: "nousresearch/hermes-3-llama-3.1-405b", base_url: "https://openrouter.ai/api/v1", key_configured: true, context_length: 131072 };
const reply = (json, ok = true) => ({ ok, json: async () => json });
let container, root;
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  mockAuthFetch.mockReset();
  mockUser = undefined;
  toast.success.mockReset(); toast.error.mockReset();
  container = document.createElement("div"); document.body.appendChild(container);
  root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); });
const mount = async () => { await act(async () => { root.render(<AdminAISettings />); }); };
async function change(value) {
  const input = container.querySelector("input");
  await act(async () => {
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(input, value);
    input.dispatchEvent(new Event("input", { bubbles: true }));
  });
}
async function submit() {
  await act(async () => container.querySelector("form").dispatchEvent(new Event("submit", { bubbles: true, cancelable: true })));
}

test("loads current model and never displays an API credential", async () => {
  mockAuthFetch.mockResolvedValue(reply(initial));
  await mount();
  expect(container.querySelector("input").value).toBe(initial.model);
  expect(container.querySelector('[data-testid="ai-active-model"]').textContent).toBe(initial.model);
  expect(container.textContent).not.toContain("sk-or-v1");
  expect(container.querySelector('[data-testid="ai-model-save"]').disabled).toBe(true);
});

test("saves a typed model ID and applies the returned setting", async () => {
  const newModel = "meta-llama/llama-3.1-8b-instruct";
  mockAuthFetch.mockResolvedValueOnce(reply(initial)).mockResolvedValueOnce(reply({ ...initial, model: newModel }));
  await mount(); await change(newModel); await submit();
  expect(mockAuthFetch.mock.calls[1]).toEqual(["/admin/ai-settings", { method: "PUT", signal: expect.any(AbortSignal), body: JSON.stringify({ model: newModel, profile_models:{kaligpt:'',deepdark:'','rsvx7-ai':''}, model_revision:0 }) }]);
  expect(container.querySelector('[data-testid="ai-active-model"]').textContent).toBe(newModel);
  expect(toast.success).toHaveBeenCalledTimes(1);
});

test("invalid model leaves the active selection unchanged and exposes a useful error", async () => {
  mockAuthFetch.mockResolvedValueOnce(reply(initial)).mockResolvedValueOnce(reply({ detail: "Unknown model" }, false));
  await mount(); await change("provider/missing"); await submit();
  expect(container.querySelector('[role="alert"]').textContent).toContain("Unknown model");
  expect(container.querySelector('[data-testid="ai-active-model"]').textContent).toBe(initial.model);
  expect(toast.success).not.toHaveBeenCalled();
  expect(container.querySelector('[data-testid="ai-model-save"]').disabled).toBe(false);
});

test("permission failure is not displayed as an empty successful settings panel", async () => {
  mockAuthFetch.mockResolvedValue(reply({ detail: "Missing permission: ai_models" }, false));
  await mount();
  expect(container.querySelector('[role="alert"]').textContent).toContain("Missing permission");
  expect(container.querySelector("input")).toBeNull();
});

test("initial network failure can be retried without a stuck spinner", async () => {
  mockAuthFetch.mockRejectedValueOnce(new TypeError("Network unavailable")).mockResolvedValueOnce(reply(initial));
  await mount();
  expect(container.querySelector('[role="alert"]').textContent).toContain("Network unavailable");
  const retry = container.querySelector("button");
  expect(retry.disabled).toBe(false);
  await act(async () => retry.click());
  expect(container.querySelector("input").value).toBe(initial.model);
});

async function enterKey(value) {
  await act(async () => {
    const field = container.querySelector('[data-testid="ai-provider-key"]');
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, "value").set.call(field, value);
    field.dispatchEvent(new Event("input", { bubbles: true }));
  });
}

test("owner configures a write-only key and clears it after saving", async () => {
  mockUser = { _id: 'owner', role: 'super_admin' };
  const configured = { ...initial, connection_revision: 3 };
  mockAuthFetch.mockResolvedValueOnce(reply({ ...initial, key_configured: false, connection_revision: 2 }))
    .mockResolvedValueOnce(reply({ settings: configured, test: { ready: true, key_valid: true } }));
  await mount(); await enterKey('fixture-new-api-key');
  await act(async () => container.querySelector('[data-testid="ai-connection-save"]').click());
  expect(mockAuthFetch.mock.calls[1]).toEqual(['/admin/ai-settings/connection', { method: 'PUT', signal: expect.any(AbortSignal), body: JSON.stringify({ revision: 2, api_key: 'fixture-new-api-key' }) }]);
  expect(container.querySelector('[data-testid="ai-provider-key"]').value).toBe('');
  expect(container.textContent).not.toContain('fixture-new-api-key');
  expect(container.querySelector('[data-testid="ai-connection-result"]').textContent).toContain('نجح فحص الاتصال');
});

test("model administrators cannot edit the provider credential", async () => {
  mockUser = { role: 'admin', permissions: ['ai_models'] };
  mockAuthFetch.mockResolvedValue(reply(initial)); await mount();
  expect(container.querySelector('[data-testid="ai-provider-key"]')).toBeNull();
  expect(container.querySelector('[data-testid="ai-model-input"]')).not.toBeNull();
});

test("connection test reports the free quota without saving or clearing the draft", async () => {
  mockUser = { role: 'super_admin' };
  mockAuthFetch.mockResolvedValueOnce(reply(initial)).mockResolvedValueOnce(reply({ ready: false, key_valid: true, warning: 'free_limit' }));
  await mount(); await enterKey('fixture-key-to-test');
  await act(async () => container.querySelector('[data-testid="ai-connection-test"]').click());
  expect(container.querySelector('[data-testid="ai-connection-result"]').textContent).toContain('الحد اليومي');
  expect(container.querySelector('[data-testid="ai-provider-key"]').value).toBe('fixture-key-to-test');
  expect(mockAuthFetch.mock.calls[1][1].method).toBe('POST');
});

test("local model setup needs no API key field", async () => {
  mockUser = { role: 'super_admin' };
  mockAuthFetch.mockResolvedValueOnce(reply({ ...initial, provider: 'Local' })).mockResolvedValueOnce(reply({ ready: true }));
  await mount();
  expect(container.querySelector('[data-testid="ai-provider-key"]')).toBeNull();
  await act(async () => container.querySelector('[data-testid="ai-connection-test"]').click());
  expect(JSON.parse(mockAuthFetch.mock.calls[1][1].body).api_key).toBe('');
});

async function changeProfile(id, value) {
  await act(async () => {
    const input = container.querySelector('[data-testid="ai-profile-' + id + '"]');
    Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(input, value);
    input.dispatchEvent(new Event('input', {bubbles:true}));
  });
}
test('each platform model can be assigned and cleared independently', async () => {
  const profiles = {kaligpt:'provider/fast',deepdark:'provider/reasoning','rsvx7-ai':'provider/code'};
  const updated = {...initial, model_revision:4, profile_models:profiles};
  mockAuthFetch.mockResolvedValueOnce(reply({...initial,model_revision:3})).mockResolvedValueOnce(reply(updated));
  const event = jest.fn(); window.addEventListener('rsvx7:ai-settings-updated', event);
  try {
    await mount();
    for (const [id,model] of Object.entries(profiles)) await changeProfile(id,model);
    expect(container.querySelector('[data-testid="ai-model-save"]').disabled).toBe(false);
    await submit();
    expect(JSON.parse(mockAuthFetch.mock.calls[1][1].body)).toEqual({model:initial.model,profile_models:profiles,model_revision:3});
    expect(event).toHaveBeenCalledTimes(1);
    expect(container.querySelector('[data-testid="ai-model-save"]').disabled).toBe(true);
    await changeProfile('deepdark','');
    mockAuthFetch.mockResolvedValueOnce(reply({...updated,model_revision:5,profile_models:{...profiles,deepdark:''}}));
    await submit();
    expect(JSON.parse(mockAuthFetch.mock.calls[2][1].body).profile_models).toEqual({...profiles,deepdark:''});
  } finally { window.removeEventListener('rsvx7:ai-settings-updated',event); }
});

test('a rejected profile mapping keeps all editable drafts and current settings', async () => {
  mockAuthFetch.mockResolvedValueOnce(reply({...initial,profile_models:{deepdark:'provider/current'}}))
    .mockResolvedValueOnce(reply({detail:'Unknown model'},false));
  await mount(); await changeProfile('deepdark','provider/missing'); await submit();
  expect(container.querySelector('[data-testid="ai-profile-deepdark"]').value).toBe('provider/missing');
  expect(container.querySelector('[data-testid="ai-active-model"]').textContent).toBe(initial.model);
  expect(container.querySelector('[role="alert"]').textContent).toContain('Unknown model');
});
