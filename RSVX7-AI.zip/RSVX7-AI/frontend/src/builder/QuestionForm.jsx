import React, { useRef, useState } from 'react';
import { Check, Send } from 'lucide-react';
import { useI18n } from '@/i18n';
import { registerTranslations } from '@/i18n/runtime';

registerTranslations('builderQuestions', {
  'إجابة أخرى أو تفاصيل إضافية': 'Another answer or additional details',
  'إرسال الإجابات': 'Send answers', 'جارٍ الإرسال…': 'Sending…',
  'اختر ما يناسبك': 'Choose what fits',
});

// Drafts belong to this account, project and exact question card. They never
// become model requests until the user submits the complete form.
export default function QuestionForm({ questions, draftKey, initialAnswers = [], disabled, onSubmit }) {
  const { t } = useI18n('builderQuestions');
  const storageKey = 'rsvx7-builder-answers:' + draftKey;
  const [answers, setAnswers] = useState(() => {
    let saved;
    try { saved = JSON.parse(sessionStorage.getItem(storageKey)); } catch {}
    const source = Array.isArray(saved) ? saved : initialAnswers;
    return questions.map(q => {
      const answer = source.find(a => a?.id === q.id);
      return { id: q.id, options: (Array.isArray(answer?.options) ? answer.options : []).filter(o => q.options.includes(o)).slice(0, q.multiple === false ? 1 : 5), text: typeof answer?.text === 'string' ? answer.text.slice(0, 2000) : '' };
    });
  });
  const sending = useRef(false);
  const [pending, setPending] = useState(false);
  const locked = disabled || pending;
  const answered = answers.filter(a => a.options.length || a.text.trim()).length;
  const change = (id, patch) => {
    if (locked) return;
    setAnswers(previous => {
      const next = previous.map(a => a.id === id ? { ...a, ...patch } : a);
      try { sessionStorage.setItem(storageKey, JSON.stringify(next)); } catch {}
      return next;
    });
  };
  return <form className="builder-questions" onSubmit={async event => {
    event.preventDefault();
    if (locked || sending.current || answered !== questions.length) return;
    sending.current = true; setPending(true);
    try { await onSubmit(answers); }
    finally { sending.current = false; setPending(false); }
  }}>
    {questions.map((q, index) => {
      const answer = answers[index];
      return <fieldset key={q.id} disabled={locked}>
        <legend>{q.label}</legend>
        <div className="builder-answer-options" aria-label={q.label}>
          {q.options.map(option => {
            const selected = answer.options.includes(option);
            return <button type="button" aria-pressed={selected} key={option} onClick={() => change(q.id, {
              options: selected ? answer.options.filter(o => o !== option) : q.multiple === false ? [option] : [...answer.options, option],
            })}><span className="builder-choice-mark" aria-hidden="true">{selected && <Check size={13} />}</span><span>{option}</span></button>;
          })}
        </div>
        <input type="text" maxLength={2000} value={answer.text} aria-label={q.label + ' — ' + t('إجابة أخرى أو تفاصيل إضافية')}
          placeholder={t('إجابة أخرى أو تفاصيل إضافية')} onChange={event => change(q.id, { text: event.target.value })} />
      </fieldset>;
    })}
    {!disabled && <div className="builder-answer-submit"><span aria-live="polite">{answered} / {questions.length}</span>
      <button className="builder-primary" type="submit" disabled={locked || answered !== questions.length}><Send size={15} />{t(pending ? 'جارٍ الإرسال…' : 'إرسال الإجابات')}</button>
    </div>}
  </form>;
}
