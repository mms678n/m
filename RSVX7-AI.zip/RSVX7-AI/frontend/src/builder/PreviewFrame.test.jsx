import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import PreviewFrame from './PreviewFrame';

let container, root, runtime;
const state = { phase: 'ready', previewRun: 4, previewPort: 5173, previewUrl: 'https://project.example.test/' };
beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  runtime = { confirmPreview: jest.fn(), reportPreviewError: jest.fn() };
  container = document.createElement('div'); document.body.appendChild(container); root = createRoot(container);
});
afterEach(async () => { await act(async () => root.unmount()); container.remove(); });
const mount = async (value = state, verification = false) => {
  await act(async () => root.render(<PreviewFrame state={value} runtime={runtime} verification={verification} />));
  return document.querySelector('iframe');
};
async function send(frame, data, origin = 'https://project.example.test') {
  await act(async () => window.dispatchEvent(new MessageEvent('message', { origin, source: frame.contentWindow,
    data: { type: 'darkforge:preview-health', run: 4, ok: false, reason: 'runtime', error: 'Click handler crashed', ...data } })));
}

test('a runtime failure after initial success reaches the repair controller', async () => {
  const frame = await mount();
  await send(frame, {});
  expect(runtime.reportPreviewError).toHaveBeenCalledWith(5173, 'DF_PREVIEW_RUNTIME: Click handler crashed', 4);
  expect(runtime.confirmPreview).not.toHaveBeenCalled();
});

test('old runs, other windows and other origins cannot report a preview error', async () => {
  const frame = await mount();
  await send(frame, { run: 3 }); await send(frame, {}, 'https://foreign.example.test');
  await act(async () => window.dispatchEvent(new MessageEvent('message', { origin: 'https://project.example.test', source: window,
    data: { type: 'darkforge:preview-health', run: 4, ok: false, reason: 'runtime' } })));
  expect(runtime.reportPreviewError).not.toHaveBeenCalled();
});

test('an inactive preview tab does not cause a false empty-page repair', async () => {
  const frame = await mount();
  await send(frame, { reason: undefined, error: 'No layout in hidden tab' });
  expect(runtime.reportPreviewError).not.toHaveBeenCalled();
});

test('the dedicated verification frame confirms the rendered startup', async () => {
  const frame = await mount({ ...state, phase: 'starting' }, true);
  await send(frame, { ok: true, reason: undefined, error: undefined });
  expect(runtime.confirmPreview).toHaveBeenCalledWith(4, 5173, true, undefined);
  expect(runtime.reportPreviewError).not.toHaveBeenCalled();
});
