import React, {act} from 'react';
import {createRoot} from 'react-dom/client';
import {BuildProgress} from './generated-widgets';
let node,root;
beforeEach(()=>{global.IS_REACT_ACT_ENVIRONMENT=true;node=document.createElement('div');document.body.appendChild(node);root=createRoot(node);});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});
test.each(['writing','repairing','failed'])('old or current internal agents stay hidden in the %s progress card',async phase=>{
  const state={phase,attempt:phase==='repairing'?1:0,files:3,checks:[],startedAt:Date.now(),agents:[
    {role:'architect',status:phase==='failed'?'failed':'running'},
    {role:'designer',status:'completed'},
    {role:'coder',status:'completed'},
    {role:'reviewer',status:'failed'},
  ]};
  await act(async()=>root.render(<BuildProgress state={state}/>));
  expect(node.querySelectorAll('.df-agent-team > span')).toHaveLength(2);
  expect(node.textContent).toContain('البرمجة');
  expect(node.textContent).toContain('مراجعة الكود');
  for(const label of ['تشخيص البنية','تشخيص التصميم','التخطيط'])expect(node.textContent).not.toContain(label);
  if(phase!=='failed')expect(node.querySelector('.df-build-heading').textContent).toContain('جارٍ إصلاح المشكلة');
});
