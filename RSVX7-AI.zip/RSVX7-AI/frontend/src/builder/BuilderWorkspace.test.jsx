import React, { act } from 'react';
import { createRoot } from 'react-dom/client';
import BuilderWorkspace from './BuilderWorkspace';
const mockFetch = jest.fn(), mockRefresh = jest.fn();
const mockRuntime = { apply: jest.fn(), dispose: jest.fn(), stop: jest.fn(), runtime: { state: { get: () => ({phase:'idle'}) }, setAgentTasks: jest.fn(), beginTask: jest.fn(), pause: jest.fn() } };
jest.mock('@/context/AuthContext', () => ({ useAuth: () => ({ user: {_id:'alice'}, authFetch: mockFetch }) }));
jest.mock('./BuilderProjectsContext', () => ({ useBuilderProjects: () => ({ activeId:'p_owned', loading:false, projects:[{_id:'p_owned',name:'Existing project'}], refresh:mockRefresh, select:jest.fn(), create:jest.fn() }) }));
jest.mock('@/context/TokensContext', () => ({ useTokens: () => ({refresh:mockRefresh}) }));
jest.mock('@/context/ChatContext', () => ({useChat: () => ({prefs:{modelId:'deepdark',deepThink:true,autoSuffix:{enabled:true,text:'Native suffix'}}})}));
jest.mock('./runtime', () => ({createRuntime: () => mockRuntime,readPreviewHealth:()=>undefined}));
jest.mock('./generated-widgets', () => ({BuildProgress:()=>null}));
jest.mock('./CodeEditor', () => ()=>null);
jest.mock('@/components/chat/Markdown', () => ({children})=><div>{children}</div>);
jest.mock('@/components/design/ThemeSwitcher', () => ()=>null);
jest.mock('@/components/chat/ChatInput', () => ({controller})=><div><button disabled={controller.isStreaming} onClick={()=>controller.sendMessage('Build a site',[])}>Send native composer</button><button onClick={()=>controller.deactivateDarkMode()}>Disable native instruction</button></div>);
let node, root, state;
const response = body => ({ok:true,json:async()=>body});
beforeEach(()=>{
  global.IS_REACT_ACT_ENVIRONMENT=true; jest.clearAllMocks(); mockRefresh.mockResolvedValue(undefined);
  Object.defineProperty(window,"crypto",{configurable:true,value:{randomUUID:()=>"fixture-request-uuid"}});
  state={revision:1,files:{'/home/project/index.html':{type:'file',content:'<h1>Existing</h1>'}},messages:[],checks:[],model:'admin/chosen-model',darkMode:true};
  mockFetch.mockImplementation(async(path,options)=>{
    if(path.endsWith('/run')) return response({job:{id:'backend-job',status:'running',mode:'build'}});
    return response(state);
  });
  node=document.createElement('div');document.body.appendChild(node);root=createRoot(node);
});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();});
async function mount(){await act(async()=>{root.render(<BuilderWorkspace/>);await Promise.resolve();});}
test('native composer carries site instructions while the server selects the model and wallet',async()=>{
  await mount();
  expect(node.textContent).toContain('admin/chosen-model');
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Disable native instruction').click());
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Send native composer').click());
  const call=mockFetch.mock.calls.find(([path])=>path.endsWith('/run'));
  const body=JSON.parse(call[1].body);
  expect(body).toMatchObject({revision:1,text:'Build a site',darkMode:false,personality:'deepdark',deepThink:true,autoSuffix:'Native suffix'});
  expect(body.model).toBeUndefined();expect(body.apiKey).toBeUndefined();
});
test('starting work preserves the selected preview tab and navigation does not cancel the backend job',async()=>{
  await mount();
  const tabs=node.querySelectorAll('[role=tab]');
  await act(async()=>tabs[2].click());
  await act(async()=>[...node.querySelectorAll('button')].find(b=>b.textContent==='Send native composer').click());
  expect(tabs[2].getAttribute('aria-selected')).toBe('true');
  await act(async()=>root.render(null));
  expect(mockRuntime.dispose).toHaveBeenCalled();
  expect(mockFetch.mock.calls.some(([path])=>path.endsWith('/cancel'))).toBe(false);
});


test('an old poll cannot replace the state of a newly accepted job', async () => {
  jest.useFakeTimers();
  try {
    await mount();
    const oldState = {...state};
    let releaseOldPoll;
    mockFetch.mockImplementationOnce(() => new Promise(resolve => { releaseOldPoll = () => resolve(response(oldState)); }));
    await act(async () => { jest.advanceTimersByTime(6000); });
    expect(releaseOldPoll).toBeDefined();
    mockFetch.mockImplementation(async (path) => {
      const job = {id:'new-job',status:'running',mode:'planning'};
      return response(path.endsWith('/run') ? {job} : {...state, job});
    });
    const send = [...node.querySelectorAll('button')].find(b => b.textContent === 'Send native composer');
    await act(async () => send.click());
    expect(send.disabled).toBe(true);
    await act(async () => releaseOldPoll());
    expect(send.disabled).toBe(true);
  } finally { jest.useRealTimers(); }
});

const questions = [
  {id:'goal', label:'ما هدف الموقع؟', options:['عرض الأعمال','بيع الخدمات'], multiple:false},
  {id:'features', label:'ما الميزات المطلوبة؟', options:['حجز مواعيد','نموذج تواصل','مدونة'], multiple:true},
];
const clickText = async text => act(async () => [...node.querySelectorAll('button')].find(b => b.textContent === text).click());
const loadQuestions = () => {
  sessionStorage.clear();
  const plan = {kind:'questions', message:'', questions};
  state = {...state, files:{}, plan, proposalId:'questions-one', messages:[{id:'questions-one',role:'assistant',content:'',plan}]};
};
test('all answers and multiple feature choices are sent once only after explicit submission', async () => {
  loadQuestions(); await mount();
  await clickText('عرض الأعمال');
  await clickText('حجز مواعيد');
  await clickText('نموذج تواصل');
  expect(mockFetch.mock.calls.filter(([path]) => path.endsWith('/run'))).toHaveLength(0);
  expect(node.querySelectorAll('[aria-pressed=true]')).toHaveLength(3);
  await clickText('إرسال الإجابات');
  const calls = mockFetch.mock.calls.filter(([path]) => path.endsWith('/run'));
  expect(calls).toHaveLength(1);
  expect(JSON.parse(calls[0][1].body)).toMatchObject({action:'answers',questionMessageId:'questions-one',answers:[
    {id:'goal',options:['عرض الأعمال'],text:''},
    {id:'features',options:['حجز مواعيد','نموذج تواصل'],text:''},
  ]});
});
test('answers are editable before sending and remain after a failed request and remount', async () => {
  loadQuestions(); await mount();
  await clickText('عرض الأعمال'); await clickText('بيع الخدمات');
  await clickText('حجز مواعيد'); await clickText('حجز مواعيد'); await clickText('مدونة');
  mockFetch.mockImplementation(async path => path.endsWith('/run') ? {ok:false,json:async()=>({detail:'connection failed'})} : response(state));
  await clickText('إرسال الإجابات');
  expect(node.textContent).toContain('connection failed');
  expect([...node.querySelectorAll('[aria-pressed=true]')].map(b=>b.textContent)).toEqual(['بيع الخدمات','مدونة']);
  await act(async () => root.render(null));
  await mount();
  expect([...node.querySelectorAll('[aria-pressed=true]')].map(b=>b.textContent)).toEqual(['بيع الخدمات','مدونة']);
});
test('an old question card is locked when a newer proposal replaces it', async () => {
  loadQuestions(); state.plan = {kind:'reply',message:'Ready'}; state.proposalId='new-plan';
  await mount();
  expect(node.querySelector('fieldset').disabled).toBe(true);
  expect(node.textContent).not.toContain('إرسال الإجابات');
});
test('retry calls the server retry action without resending the user answer', async () => {
  loadQuestions(); state.job={id:'failed',status:'failed',mode:'planning',error:'Planning failed'};
  await mount(); await clickText('إعادة المحاولة');
  const call=mockFetch.mock.calls.find(([path])=>path.endsWith('/run'));
  expect(JSON.parse(call[1].body)).toMatchObject({action:'retry',text:''});
});

test('an ambiguous network failure retries the same request ID without another turn', async () => {
  loadQuestions(); await mount();
  let id = 0;
  window.crypto.randomUUID = () => 'fixture-request-' + ++id;
  await clickText('عرض الأعمال'); await clickText('حجز مواعيد');
  mockFetch.mockImplementation(async (path) => {
    if (path.endsWith('/run')) throw new Error('Connection interrupted');
    return response(state);
  });
  await clickText('إرسال الإجابات'); await clickText('إرسال الإجابات');
  const calls = mockFetch.mock.calls.filter(([path]) => path.endsWith('/run')).map(([,options]) => JSON.parse(options.body));
  expect(calls).toHaveLength(2);
  expect(calls[0].requestId).toBe(calls[1].requestId);
  expect(id).toBe(1);
});

test('retry of a failed code repair preserves the runtime repair workflow', async () => {
  state.job = {id:'failed-repair',status:'failed',mode:'build',error:'Connection interrupted',request:{action:'repair'}};
  await mount();
  mockFetch.mockImplementation(async path => {
    const job = {id:'retry-repair',status:'running',mode:'build',request:{action:'repair'}};
    return response(path.endsWith('/run') ? {job} : {...state,job});
  });
  await clickText('إعادة المحاولة');
  expect(mockRuntime.runtime.beginTask).toHaveBeenLastCalledWith(true, true);
});

test.each(['DF_CHAT_ERROR:{"code":"agent_format"}','لم يرسل أحد الوكلاء ملفات أو تقريرًا صالحًا. أعد المحاولة أو اختر نموذجًا آخر.'])('stored protocol failure %s uses the current readable error',async error=>{
  state.job={id:'old-failure',status:'failed',mode:'build',error};
  await mount();
  expect(node.textContent).not.toContain('DF_CHAT_ERROR');
  expect(node.textContent).not.toContain('لم يرسل أحد الوكلاء');
  expect(node.textContent).toContain('تعذّر قراءة مخرجات');
  expect(mockRuntime.runtime.pause).toHaveBeenCalledWith(expect.stringContaining('تعذّر قراءة مخرجات'));
});
