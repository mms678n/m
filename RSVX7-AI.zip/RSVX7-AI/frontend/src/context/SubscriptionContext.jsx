import React, { createContext, useCallback, useContext, useMemo, useState } from "react";
import SubscriptionRequiredDialog from "@/components/SubscriptionRequiredDialog";
import "@/i18n/catalogs/services";

const Ctx = createContext(null);

// Central gate for the "expired subscription" state. Any part of the app can:
//   - Read `isExpired` to disable inputs proactively (chat input, upload buttons)
//   - Call `openRenewalModal(err?)` when they see a 402 subscription_required
//   - Call `guard()` before performing a client-only feature (e.g. cross-check
//     before dispatching a paid API call)
//
// The dialog itself renders once at the app root. A click on "Renew" navigates
// to the dashboard's subscription section (or triggers `onOpenDashboard` if the
// consumer passed one to <SubscriptionProvider>).
export function SubscriptionProvider({ children, onOpenDashboard }) {
  const [modal, setModal] = useState(null); // {message, cta}

  // Wallet model — there is no such thing as "expired" anymore. Kept as
  // a stable no-op so existing imports don't break.
  const isExpired = false;

  const openRenewalModal = useCallback((detail) => {
    let m = detail;
    if (m && m.detail) m = m.detail;
    if (typeof m === "string") m = { message: m };
    setModal({
      message: m?.message || "نفد رصيد التوكنات. يرجى شحن الرصيد للمتابعة.",
      cta: m?.cta || "شحن الرصيد",
    });
  }, []);

  const close = useCallback(() => setModal(null), []);
  const renew = useCallback(() => {
    setModal(null);
    if (onOpenDashboard) onOpenDashboard();
    else window.location.hash = "#dashboard";
  }, [onOpenDashboard]);

  const value = useMemo(() => ({
    isExpired,
    openRenewalModal,
  }), [isExpired, openRenewalModal]);

  return (
    <Ctx.Provider value={value}>
      {children}
      <SubscriptionRequiredDialog
        open={!!modal}
        onClose={close}
        onRenew={renew}
        message={modal?.message}
        cta={modal?.cta}
      />
    </Ctx.Provider>
  );
}

export const useSubscription = () => {
  const c = useContext(Ctx);
  if (!c) throw new Error("useSubscription must be used within SubscriptionProvider");
  return c;
};

// Convenience: parse a fetch Response (or thrown Error) and, if it's a 402
// insufficient_tokens payload, open the top-up modal. Returns true if handled.
export function handleSubscriptionError(err, sub) {
  try {
    const candidates = [
      err?.detail,
      err?.body?.detail,
      err?.data?.detail,
      err?.response?.data?.detail,
      err?.error?.detail,
      err?.body,
      err?.data,
    ];
    let detail = candidates.find((value) => value && typeof value === "object" && !Array.isArray(value));
    if (!detail) {
      const text = typeof err?.message === "string" ? err.message : "";
      const m = text.match(/\{[\s\S]*\}/);
      if (m) {
        try {
          const parsed = JSON.parse(m[0]);
          detail = parsed?.detail && typeof parsed.detail === "object" ? parsed.detail : parsed;
        } catch {}
      }
    }
    const status = Number(err?.status || err?.statusCode || err?.response?.status || 0);
    if (detail && (detail.code === "insufficient_tokens" || detail.code === "subscription_required") &&
        (!status || status === 402)) {
      sub?.openRenewalModal(detail);
      return true;
    }
  } catch {}
  return false;
}
