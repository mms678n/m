import React, { createContext, useContext, useEffect, useState, useCallback } from "react";
import { t, formatNumber } from "@/i18n";
import "@/i18n/catalogs/services";

const Ctx = createContext(null);
const serviceT = (source, variables) => t(source, variables, "services");
const BACKEND = (process.env.REACT_APP_BACKEND_URL || "");
const API = `${BACKEND}/api`;

const FRIENDLY = {
  "Invalid credentials": "اسم المستخدم أو كلمة المرور غير صحيحة.",
  "Username already exists": "اسم المستخدم هذا مستخدم بالفعل. جرّب اسمًا آخر.",
  "Account suspended": "حسابك موقوف. يُرجى التواصل مع المسؤول.",
  "Token expired": "انتهت جلستك. يُرجى تسجيل الدخول مرة أخرى.",
  "Invalid token": "جلستك غير صالحة. يُرجى تسجيل الدخول مرة أخرى.",
  "Session revoked": "تم إلغاء جلستك. يُرجى تسجيل الدخول مرة أخرى.",
  "Invalid username or recovery code": "اسم المستخدم أو رمز الاسترداد غير صحيح.",
  "Old password incorrect": "كلمة المرور الحالية التي أدخلتها غير صحيحة.",
};
const friendly = (msg) => serviceT(FRIENDLY[msg] || msg || "حدث خطأ ما. حاول مرة أخرى.");

async function readError(r) {
  try {
    const d = await r.json();
    // SEC-010: dedicated banned-IP message. Backend returns
    // detail: {code:"ip_banned", message:"تم حظرك..."}
    if (d?.detail && typeof d.detail === "object" && d.detail.code === "ip_banned") {
      return serviceT("تم حظرك من قِبَل المسؤول.");
    }
    return d?.detail ? friendly(d.detail) : serviceT("فشل الطلب ({status}).", { status: formatNumber(r.status) });
  } catch {
    if (!navigator.onLine) return serviceT("لا يوجد اتصال بالإنترنت.");
    if (r.status >= 500) return serviceT("خوادمنا تواجه مشكلة مؤقتة. حاول مرة أخرى.");
    return serviceT("فشل الطلب ({status}).", { status: formatNumber(r.status) });
  }
}

const wrap = async (fn) => {
  try { return await fn(); }
  catch (e) {
    if (e?.name === "TypeError") throw new Error(serviceT("تعذّر الوصول إلى الخادم. تحقق من اتصالك."));
    throw e;
  }
};

export function AuthProvider({ children }) {
  const [user, setUser] = useState(undefined); // undefined=loading, null=guest, object=auth
  const [token, setToken] = useState(localStorage.getItem("rsvx7_token") || "");

  const authFetch = useCallback(async (path, opts = {}) => {
    const t = localStorage.getItem("rsvx7_token") || "";
    const headers = { ...(opts.headers || {}) };
    if (t) headers.Authorization = `Bearer ${t}`;
    if (opts.body && !(opts.body instanceof FormData) && !headers["Content-Type"]) {
      headers["Content-Type"] = "application/json";
    }
    const r = await fetch(`${API}${path}`, { ...opts, headers, credentials: "include" });
    if (r.status === 401) {
      localStorage.removeItem("rsvx7_token");
      window.dispatchEvent(new CustomEvent("rsvx7:auth-expired"));
    }
    return r;
  }, []);

  const refresh = useCallback(async (t) => {
    const useTok = t ?? (localStorage.getItem("rsvx7_token") || "");
    try {
      const headers = useTok ? { Authorization: `Bearer ${useTok}` } : {};
      // An HttpOnly access cookie is a valid session even when localStorage is empty.
      const r = await fetch(`${API}/auth/me`, { headers, credentials: "include" });
      if (r.ok) { const u = await r.json(); setUser(u); return u; }
      setUser(null); setToken(""); localStorage.removeItem("rsvx7_token"); return null;
    } catch {
      // Network error: keep token, mark as guest until next try so UX recovers gracefully.
      setUser(null); return null;
    }
  }, []);

  useEffect(() => { refresh(); }, [refresh]);

  // Listen for global session-expired events fired by aiClient on 401.
  useEffect(() => {
    const onExpired = () => { setToken(""); setUser(null); };
    window.addEventListener("rsvx7:auth-expired", onExpired);
    return () => window.removeEventListener("rsvx7:auth-expired", onExpired);
  }, []);

  const login = useCallback(async (username, password, remember_me) => {
    return wrap(async () => {
      const r = await fetch(`${API}/auth/login`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ username, password, remember_me }),
      });
      if (!r.ok) throw new Error(await readError(r));
      const d = await r.json();
      localStorage.setItem("rsvx7_token", d.token);
      setToken(d.token);
      await refresh(d.token);
      return d;
    });
  }, [refresh]);

  const register = useCallback(async (username, password, ref) => {
    return wrap(async () => {
      const r = await fetch(`${API}/auth/register`, {
        method: "POST", headers: { "Content-Type": "application/json" }, credentials: "include",
        body: JSON.stringify({ username, password, ref: ref || undefined }),
      });
      if (!r.ok) throw new Error(await readError(r));
      return r.json();
    });
  }, []);

  const activateSession = useCallback(async (t) => {
    if (!t) return null;
    localStorage.setItem("rsvx7_token", t);
    setToken(t);
    return refresh(t);
  }, [refresh]);

  const recover = useCallback(async (username, recovery_code, new_password) => {
    return wrap(async () => {
      const r = await fetch(`${API}/auth/recover`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ username, recovery_code, new_password }),
      });
      if (!r.ok) throw new Error(await readError(r));
      return r.json();
    });
  }, []);

  const changePassword = useCallback(async (old_password, new_password) => {
    return wrap(async () => {
      const r = await authFetch("/auth/change-password", {
        method: "POST",
        body: JSON.stringify({ old_password, new_password }),
      });
      if (!r.ok) throw new Error(await readError(r));
      const d = await r.json();
      if (d.token) {
        localStorage.setItem("rsvx7_token", d.token);
        setToken(d.token);
      }
      await refresh(d.token);
      return d;
    });
  }, [authFetch, refresh]);

  const logout = useCallback(async () => {
    await fetch(`${API}/auth/logout`, { method: "POST", credentials: "include" }).catch(() => {});
    localStorage.removeItem("rsvx7_token");
    setToken(""); setUser(null);
  }, []);

  return (
    <Ctx.Provider value={{ user, token, login, register, activateSession, recover, changePassword, logout, refresh, authFetch }}>
      {children}
    </Ctx.Provider>
  );
}

export const useAuth = () => useContext(Ctx);
