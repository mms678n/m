import React from "react";
import { act } from "react";
import { createRoot } from "react-dom/client";

jest.mock("@/lib/aiClient", () => ({
  streamChat: jest.fn(),
  suggestedTitle: jest.fn(() => "New chat"),
}));
jest.mock("@/components/chat/ModelPicker", () => ({
  DEFAULT_MODEL_ID: "default-model",
  backendModelFor: jest.fn((value) => value),
}));
jest.mock("@/context/WorkspaceContext", () => ({
  useWorkspace: () => ({ currentProjectId: null }),
}));
jest.mock("@/context/TokensContext", () => ({
  useTokens: () => ({ applyUsage: jest.fn() }),
}));
jest.mock("@/context/AuthContext", () => ({
  useAuth: () => ({ user: null }),
}));
jest.mock("@/context/streamStore", () => ({
  streamStore: {
    start: jest.fn(), push: jest.fn(), pushReasoning: jest.fn(), flush: jest.fn(), stop: jest.fn(),
    recordChunk: jest.fn(), getSnapshot: jest.fn(() => null), getActiveId: jest.fn(() => null),
  },
}));
jest.mock("@/lib/workspaceClient", () => ({
  wsListConversations: jest.fn(),
  wsCreateConversation: jest.fn(),
  wsGetConversation: jest.fn(),
  wsUpdateConversation: jest.fn(),
  wsDeleteConversation: jest.fn(),
  wsSaveTurn: jest.fn(),
}));
jest.mock("sonner", () => ({ toast: { error: jest.fn(), success: jest.fn() } }));

import { ChatProvider, useChat } from "./ChatContext";
import * as aiClient from "@/lib/aiClient";
import * as tokensContext from "@/context/TokensContext";
import * as streamStoreModule from "@/context/streamStore";

const mockStreamChat = aiClient.streamChat;
const mockApplyUsage = tokensContext.useTokens().applyUsage;
const mockStreamStore = streamStoreModule.streamStore;

let container;
let root;
let api;
let renderCount;

function Probe() {
  renderCount += 1;
  api = useChat();
  return null;
}

beforeEach(() => {
  global.IS_REACT_ACT_ENVIRONMENT = true;
  localStorage.clear();
  mockStreamChat.mockReset();
  mockApplyUsage.mockReset();
  Object.values(mockStreamStore).forEach((method) => method.mockClear());
  renderCount = 0;
  api = null;
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
  mockStreamChat.mockImplementation(() => Promise.resolve());
});

afterEach(async () => {
  await act(async () => root.unmount());
  container.remove();
});

test("forwards guarded server phases without rendering once per token", async () => {
  let streamOptions;
  mockStreamChat.mockImplementation((_messages, options) => {
    streamOptions = options;
    return Promise.resolve();
  });

  await act(async () => root.render(<ChatProvider><Probe /></ChatProvider>));
  await act(async () => { expect(api.sendMessage("hello")).toBe(true); });

  expect(api.phase).toBe("connecting");
  expect(api.status).toEqual({ phase: "connecting" });
  expect(streamOptions.onStatus).toBeDefined();
  expect(streamOptions.deepThink).toBe(false);
  await act(async () => streamOptions.onStatus({ phase: "thinking" }));
  await act(async () => streamOptions.onReasoning("actual provider text"));
  expect(api.phase).toBe("thinking");
  expect(mockStreamStore.pushReasoning).toHaveBeenCalledWith("actual provider text");

  await act(async () => streamOptions.onStatus({ phase: "streaming", ttft_ms: 42 }));
  expect(api.phase).toBe("streaming");
  expect(api.status).toEqual({ phase: "streaming", ttft_ms: 42 });

  const rendersBeforeToken = renderCount;
  await act(async () => streamOptions.onChunk("one token"));
  expect(renderCount).toBe(rendersBeforeToken);
  expect(api.phase).toBe("streaming");

  await act(async () => streamOptions.onStatus({ phase: "finalizing" }));
  expect(api.phase).toBe("finalizing");
  await act(async () => streamOptions.onDone("answer", "stop"));
  expect(api.phase).toBe("idle");
  expect(api.status).toBeNull();
  const completed = api.activeChat.messages.find((item) => item.role === "assistant");
  expect(completed.reasoning).toBe("actual provider text");
  expect(completed.finishReason).toBe("stop");

  // The old callback cannot revive a completed run or overwrite idle status.
  await act(async () => streamOptions.onStatus({ phase: "streaming" }));
  expect(api.phase).toBe("idle");
  expect(api.status).toBeNull();
});

test("abort and error paths both return the context to idle", async () => {
  let streamOptions;
  mockStreamChat.mockImplementation((_messages, options) => {
    streamOptions = options;
    return Promise.resolve();
  });

  await act(async () => root.render(<ChatProvider><Probe /></ChatProvider>));
  await act(async () => { expect(api.sendMessage("abort me")).toBe(true); });
  await act(async () => api.abort());
  expect(api.phase).toBe("idle");
  expect(api.status).toBeNull();
  await act(async () => streamOptions.onStatus({ phase: "finalizing" }));
  expect(api.phase).toBe("idle");

  await act(async () => { expect(api.sendMessage("fail me")).toBe(true); });
  await act(async () => streamOptions.onError(new Error("network")));
  expect(api.phase).toBe("idle");
  expect(api.status).toBeNull();
});
