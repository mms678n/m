import React, { act, useState } from "react";
import { createRoot } from "react-dom/client";
import { LanguageProvider, LanguageSwitcher, useI18n, setLanguage, registerTranslations, translate, formatNumber, formatDate, LANGUAGE_KEY } from "./index";
let node, root;
beforeEach(() => { global.IS_REACT_ACT_ENVIRONMENT = true; localStorage.clear(); setLanguage("ar"); node=document.createElement("div"); document.body.append(node); root=createRoot(node); });
afterEach(() => { act(() => root.unmount()); node.remove(); setLanguage("ar"); });
function Probe() { const { t, dir }=useI18n("test"); const [value,setValue]=useState(""); return <div dir={dir} data-testid="probe"><LanguageSwitcher /><p>{t("رسالة {name}",{name:"User-Owned"})}</p><input value={value} onChange={e=>setValue(e.target.value)} /></div>; }
test("switches immediately and preserves form value and user content", () => {
 registerTranslations("test",{"رسالة {name}":"Message {name}"});
 act(() => root.render(<LanguageProvider><Probe /></LanguageProvider>));
 const input=node.querySelector("input"); const setter=Object.getOwnPropertyDescriptor(HTMLInputElement.prototype,"value").set;
 act(()=>{setter.call(input,"نص user-owned unchanged");input.dispatchEvent(new Event("input",{bubbles:true}));});
 act(()=>{const picker=node.querySelector("select");picker.value="en";picker.dispatchEvent(new Event("change",{bubbles:true}));});
 expect(node.textContent).toContain("Message User-Owned"); expect(input.value).toBe("نص user-owned unchanged"); expect(document.documentElement.lang).toBe("en");expect(document.documentElement.dir).toBe("ltr");expect(localStorage.getItem(LANGUAGE_KEY)).toBe("en");
 act(()=>setLanguage("ar"));expect(node.textContent).toContain("رسالة User-Owned");expect(document.documentElement.dir).toBe("rtl");
});
test("known labels interpolate but unknown content remains untouched",()=>{setLanguage("en");expect(translate("حفظ")).toBe("Save");expect(translate("{count} item",{count:3})).toBe("3 item");expect(translate("محتوى فريد للمستخدم")).toBe("محتوى فريد للمستخدم");expect(translate("{missing}")).toBe("{missing}");});
test("rejects unsupported languages and safely formats values",()=>{setLanguage("en");setLanguage("fr");expect(localStorage.getItem(LANGUAGE_KEY)).toBe("en");expect(formatNumber(1234)).toBe("1,234");expect(formatNumber(Infinity)).toBe("∞");expect(formatDate("invalid")).toBe("—");expect(formatDate(null)).toBe("—");expect(formatDate("2026-10-04T12:00:00Z",{year:"numeric",month:"long",day:"numeric"})).toContain("October");});
test("storage event updates another open tab without reload",()=>{act(()=>root.render(<LanguageProvider><Probe /></LanguageProvider>));act(()=>window.dispatchEvent(new StorageEvent("storage",{key:LANGUAGE_KEY,newValue:"en"})));expect(document.documentElement.dir).toBe("ltr");});
test("known saved interface errors can switch back to Arabic without translating arbitrary content",()=>{registerTranslations("errors-test",{"تعذّر الإجراء":"Action failed"});setLanguage("en");const saved=translate("تعذّر الإجراء",{},"errors-test");expect(saved).toBe("Action failed");setLanguage("ar");expect(translate(saved)).toBe("تعذّر الإجراء");expect(translate("My project named by the user")).toBe("My project named by the user");});
