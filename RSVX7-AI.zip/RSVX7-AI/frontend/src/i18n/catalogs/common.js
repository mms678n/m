import { registerTranslations } from "../runtime";
registerTranslations("common", {
  "تعذّر إرسال الطلب": "Unable to send the request",
  "إغلاق الشريط الجانبي": "Close sidebar",
  "← العودة إلى الدردشة": "← Back to chat",
  "الأجهزة والخوادم": "Devices and servers",
  "تحكم SSH وAgent": "SSH and Agent control",
  "التبديل إلى المظهر الفاتح": "Switch to light theme",
  "التبديل إلى المظهر الداكن": "Switch to dark theme",
  "الرئيسية": "Home",
  "العودة إلى المحادثة": "Back to chat", "لا توجد بيانات بعد": "No data yet",
  "اللغة": "Language", "حفظ": "Save", "إلغاء": "Cancel", "إغلاق": "Close", "إعادة المحاولة": "Retry", "تحديث": "Refresh", "حذف": "Delete", "نسخ": "Copy", "تم النسخ": "Copied", "بحث": "Search", "تحميل": "Download", "إرسال": "Send", "إيقاف": "Stop", "فتح": "Open", "تعديل": "Edit", "التالي": "Next", "السابق": "Previous", "نعم": "Yes", "لا": "No", "موافق": "OK", "العودة": "Back", "تسجيل الخروج": "Sign out", "الإعدادات": "Settings", "لوحة الحساب": "Account", "لوحة الإدارة": "Administration", "الرصيد": "Balance", "الحساب": "Account", "الاسم": "Name", "الحالة": "Status", "جارٍ التحميل…": "Loading…", "جارٍ التحميل...": "Loading…", "جاري التحميل...": "Loading…", "جارٍ الحفظ…": "Saving…", "لم تتوفر بيانات بعد": "No data yet", "تعذّر الاتصال بالخادم": "Unable to connect to the server", "تعذّر الحفظ": "Could not save", "تعذّر تحميل البيانات": "Could not load the data", "جارٍ فتح مساحتك…": "Opening your workspace…", "تعذّر فتح هذه الشاشة. جرّب إعادة تحميل الصفحة.": "This screen could not be opened. Try reloading the page.", "إعادة تحميل الصفحة": "Reload page", "تسجيل الدخول": "Sign in", "إنشاء حساب": "Create account", "استرداد الحساب": "Recover account", "العودة للمحادثة": "Back to chat", "غير متاح": "Unavailable", "لا توجد نتائج": "No results", "محادثة جديدة": "New chat", "أنت": "You"
});
