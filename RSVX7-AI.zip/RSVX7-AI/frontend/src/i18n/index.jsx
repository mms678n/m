import React, { useLayoutEffect, useMemo, useSyncExternalStore } from "react";
import { Languages } from "lucide-react";
import { getLanguage, setLanguage, subscribeLanguage, translate, formatNumber, formatDate } from "./runtime";
import "./catalogs/common";
import "./language.css";
export * from "./runtime";
export function useI18n(namespace = "common") {
  const language = useSyncExternalStore(subscribeLanguage, getLanguage, () => "ar");
  return useMemo(() => ({ language, lang: language, locale: language === "en" ? "en-US" : "ar", dir: language === "en" ? "ltr" : "rtl", setLanguage,
    t: (source, variables) => translate(source, variables, namespace, language), formatNumber, formatDate }), [language, namespace]);
}
export function LanguageProvider({ children }) {
  const { language, dir } = useI18n();
  useLayoutEffect(() => {
    document.documentElement.lang = language;
    document.documentElement.dir = dir;
    document.documentElement.style.setProperty("--ui-direction", dir);
    document.title = language === "en" ? "rsvx7 — Cybersecurity & Penetration Testing AI" : "rsvx7 — الذكاء الاصطناعي للأمن السيبراني واختبار الاختراق";
    const description = document.querySelector('meta[name="description"]');
    if (description) description.content = language === "en" ? "rsvx7 — AI for cybersecurity, penetration testing, vulnerability analysis and security code review, with saved project context." : "rsvx7 — مساعد متخصص في الأمن السيبراني واختبار الاختراق وتحليل الثغرات ومراجعة الكود الأمني، مع سياق مشاريع محفوظ.";
  }, [language, dir]);
  return children;
}
export function LanguageSwitcher({ className = "" }) {
  const { language, setLanguage, t } = useI18n();
  return <label className={`language-switcher ${className}`}>
    <Languages size={14} aria-hidden="true" />
    <select data-testid="language-switcher" aria-label={t("اللغة")} value={language} onChange={(event) => setLanguage(event.target.value)}>
      <option value="ar">العربية</option><option value="en">English</option>
    </select>
  </label>;
}
