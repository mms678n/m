import React, { act } from "react";
import { createRoot } from "react-dom/client";
import App from "./App";
let mockUser = null;
jest.mock("@/context/AuthContext",()=>({AuthProvider:({children})=><>{children}</>,useAuth:()=>({user:mockUser})}));
jest.mock("@/pages/Landing",()=>function Landing({onSignIn,onRegister}){return <div data-testid="public-home"><button onClick={onSignIn}>login</button><button onClick={onRegister}>register</button></div>;});
jest.mock("@/pages/Login",()=>()=> <div data-testid="login" />);
jest.mock("@/pages/Register",()=>()=> <div data-testid="register" />);
jest.mock("@/pages/Recover",()=>()=> <div data-testid="recover" />);
jest.mock("@/pages/Admin",()=>()=> <div data-testid="admin" />);
jest.mock("@/pages/Dashboard",()=>()=> <div data-testid="dashboard" />);
jest.mock("@/components/design/ChatWorkspace",()=>({builderMode})=> <div data-testid="workspace" data-builder={String(!!builderMode)} />);
jest.mock("@/components/ForcePasswordChange",()=>()=> <div data-testid="force-password" />);
jest.mock("@/components/TelegramGate",()=>({children})=><div data-testid="telegram-gate">{children}</div>);
jest.mock("sonner",()=>({Toaster:()=>null}));
let node,root;
beforeEach(()=>{global.IS_REACT_ACT_ENVIRONMENT=true;mockUser=null;window.history.replaceState({},"","/");node=document.createElement("div");document.body.appendChild(node);root=createRoot(node);});
afterEach(async()=>{await act(async()=>root.unmount());node.remove();window.history.replaceState({},"","/");});
async function mount(path,user=null){window.history.replaceState({},"",path);mockUser=user;await act(async()=>{root.render(<App/>);await Promise.resolve();});}
test("public home is visible even while the authentication request is pending",async()=>{await mount("/",undefined);expect(node.querySelector('[data-testid="public-home"]')).not.toBeNull();});
test("home login action opens the actual login screen",async()=>{await mount("/");await act(async()=>{node.querySelector("button").click();});expect(node.querySelector('[data-testid="login"]')).not.toBeNull();});
test("direct /login and /register paths map to the corresponding public form",async()=>{await mount("/register");expect(node.querySelector('[data-testid="register"]')).not.toBeNull();});
test("member chat remains behind the Telegram gate",async()=>{await mount("/#chat",{_id:"member",role:"user",must_change_password:false});expect(node.querySelector('[data-testid="telegram-gate"]')).not.toBeNull();expect(node.querySelector('[data-testid="workspace"]')).not.toBeNull();});
test("mandatory password change remains before any protected workspace",async()=>{await mount("/chat",{_id:"member",role:"user",must_change_password:true});expect(node.querySelector('[data-testid="force-password"]')).not.toBeNull();expect(node.querySelector('[data-testid="workspace"]')).toBeNull();});

test("Builder uses the same member gate and native workspace",async()=>{await mount("/#builder",{_id:"member",role:"user",must_change_password:false});expect(node.querySelector('[data-testid="telegram-gate"]')).not.toBeNull();expect(node.querySelector('[data-testid="workspace"]').dataset.builder).toBe("true");});
