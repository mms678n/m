"""Production entrypoint: one origin for FastAPI and the built React app."""
import asyncio
import os
from pathlib import Path

from dotenv import load_dotenv
from fastapi import HTTPException
from fastapi.responses import FileResponse, JSONResponse
from asset_serving import CompressedStaticFiles
from session_config import session_signing_secret
from persistence import selected_backend, ping_database, verify_database

ROOT = Path(__file__).resolve().parent.parent
load_dotenv(ROOT / "backend" / ".env")
load_dotenv(ROOT / ".env")

required = ("DATABASE_URL",) if selected_backend() == "mysql" else ("MONGO_URL", "DB_NAME")
for name in required:
    if not os.environ.get(name):
        raise RuntimeError(f"Required environment variable is missing: {name}")
session_signing_secret(require_configured=True)

from server import app  # noqa: E402

BUILD = Path(os.environ.get("FRONTEND_BUILD_DIR", str(ROOT / "frontend" / "build"))).resolve()
if not (BUILD / "index.html").is_file():
    raise RuntimeError("Frontend build is missing; run pnpm build in frontend first")


@app.get("/healthz", include_in_schema=False)
async def health():
    return {"status": "ok", "service": "rsvx7-ai"}


@app.get("/readyz", include_in_schema=False)
async def ready():
    try:
        await asyncio.wait_for(ping_database(), timeout=3)
        await asyncio.wait_for(verify_database(), timeout=3)
    except Exception:
        return JSONResponse({"status": "unavailable", "database": "unreachable_or_unprepared"}, status_code=503)
    return {"status": "ready", "database": "connected", "persistence": selected_backend(),
            **({"release": os.environ["RSVX7_RELEASE_ID"]} if os.environ.get("RSVX7_RELEASE_ID") else {})}


app.mount("/static", CompressedStaticFiles(directory=BUILD / "static"), name="static")


from fastapi.staticfiles import StaticFiles
app.mount('/remote-ui', StaticFiles(directory=BUILD / 'remote', html=True), name='remote-ui')

@app.get("/{path:path}", include_in_schema=False)
async def frontend(path: str):
    # Never return the SPA shell for unknown APIs, assets or private files.
    if path == "api" or path.startswith("api/"):
        raise HTTPException(404, "API endpoint not found")
    if any(part.startswith(".") for part in path.split("/")):
        raise HTTPException(404, "Not found")
    requested = (BUILD / path).resolve()
    if not requested.is_relative_to(BUILD):
        raise HTTPException(404, "Not found")
    if requested.is_file():
        cache = "public, max-age=31536000, immutable" if path.startswith("fonts/") and requested.suffix in {".woff2", ".ttf"} else "no-cache"
        return FileResponse(requested, headers={"Cache-Control": cache})
    if path and ("." in path.rsplit("/", 1)[-1] or path.split("/", 1)[0] in {"private", "backend", "frontend", "scripts"}):
        raise HTTPException(404, "Not found")
    return FileResponse(BUILD / "index.html", headers={"Cache-Control": "no-cache"})
