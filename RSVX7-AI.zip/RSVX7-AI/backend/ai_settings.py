"""Server-only model settings, encrypted credentials and per-request connection snapshots."""
import os
import re
import secrets
import asyncio
import base64
import hashlib
import hmac
from contextvars import ContextVar
from datetime import datetime, timezone, timedelta

import httpx
from fastapi import APIRouter, Depends, HTTPException
from openai import AsyncOpenAI
from pydantic import BaseModel, Field, SecretStr, field_validator
from pymongo.errors import DuplicateKeyError
from cryptography.fernet import Fernet, InvalidToken

from auth import db, JWT_SECRET, current_user, require_permission, require_super_admin

AI_PROVIDER = os.environ.get("AI_PROVIDER", "openrouter").lower()
DEFAULT_MODEL = os.environ.get("OPENROUTER_MODEL") or ("qwen2.5-coder:7b" if AI_PROVIDER == "local" else "nousresearch/hermes-3-llama-3.1-405b")
BASE_URL = (os.environ.get("OPENROUTER_BASE_URL") or ("http://ollama:11434/v1" if AI_PROVIDER == "local" else "https://openrouter.ai/api/v1")).rstrip("/")
API_KEY = os.environ.get("OPENROUTER_API_KEY") or os.environ.get("DEEPSEEK_API_KEY") or ("local-ollama" if AI_PROVIDER == "local" else None)
DEFAULT_PARAMETERS = ["temperature", "top_p", "max_tokens"]
PROFILE_IDS = ('kaligpt', 'deepdark', 'rsvx7-ai')
DEFAULT_PROFILE = 'rsvx7-ai'
MODEL_FIELDS = ('model', 'context_length', 'max_completion_tokens', 'supported_parameters', 'reasoning')
router = APIRouter(prefix="/api/admin/ai-settings", tags=["AI settings"])
capabilities_router = APIRouter(prefix="/api/ai", tags=["AI"])

headers = {}
if os.environ.get("OPENROUTER_SITE_URL"):
    headers["HTTP-Referer"] = os.environ["OPENROUTER_SITE_URL"]
headers["X-Title"] = os.environ.get("OPENROUTER_SITE_NAME", "rsvx7")
client = AsyncOpenAI(api_key=API_KEY, base_url=BASE_URL, default_headers=headers,
                     timeout=httpx.Timeout(120.0, connect=10.0, write=30.0, pool=10.0),
                     max_retries=0) if API_KEY else None

_UNSET = object()
_request_key = ContextVar('rsvx7_model_credential', default=_UNSET)
_configured_clients = {}


def credential_cipher():
    key = hmac.new(JWT_SECRET.encode(), b'rsvx7-ai-provider-key-v1', hashlib.sha256).digest()
    return Fernet(base64.urlsafe_b64encode(key))


def configured_key(saved):
    if AI_PROVIDER == 'local':
        return API_KEY or 'local-ollama'
    if saved.get('provider_secret'):
        try:
            return credential_cipher().decrypt(saved['provider_secret'].encode()).decode()
        except (InvalidToken, ValueError, UnicodeError):
            return None
    return API_KEY


def request_client(fallback=None):
    """Use the credential snapshot selected for this request, including streams."""
    value = _request_key.get()
    return fallback if value is _UNSET else select_client(value)


def select_client(key):
    if not key:
        return None
    if key == API_KEY:
        return client
    identity = hashlib.sha256((BASE_URL + '\0' + key).encode()).hexdigest()
    if identity not in _configured_clients:
        _configured_clients[identity] = AsyncOpenAI(api_key=key, base_url=BASE_URL, default_headers=headers,
            timeout=httpx.Timeout(120.0, connect=10.0, write=30.0, pool=10.0), max_retries=0)
    return _configured_clients[identity]


async def close_provider_clients():
    # Old clients stay alive until shutdown so rotation cannot interrupt a stream.
    clients = {id(value): value for value in [client, *_configured_clients.values()] if value is not None}
    await asyncio.gather(*(value.close() for value in clients.values()), return_exceptions=True)
    _configured_clients.clear()


class ModelSettingsBody(BaseModel):
    model: str = Field(min_length=3, max_length=200)
    profile_models: dict[str, str] | None = Field(default=None, max_length=3)
    model_revision: int | None = Field(default=None, ge=0)

    @field_validator("model")
    @classmethod
    def validate_model(cls, value: str) -> str:
        value = value.strip()
        pattern = r"[A-Za-z0-9][A-Za-z0-9_.:/-]{0,199}" if AI_PROVIDER == "local" else r"[A-Za-z0-9_.-]+/[A-Za-z0-9_.:-]+"
        if not re.fullmatch(pattern, value):
            raise ValueError("Use an installed local model ID such as model:tag" if AI_PROVIDER == "local" else "Use an OpenRouter model ID such as provider/model-name")
        return value

    @field_validator('profile_models')
    @classmethod
    def validate_profiles(cls, value):
        if value is None: return None
        if set(value) - set(PROFILE_IDS): raise ValueError('Unknown platform model')
        return {profile: cls.validate_model(model) if model.strip() else '' for profile, model in value.items()}


def reasoning_capabilities(settings: dict) -> dict:
    """Return the small, public reasoning contract for a saved model.

    OpenRouter's catalog has used both ``supported_parameters`` and the richer
    ``reasoning`` object over time.  Keep both facts from the catalog, but make
    the client-facing decision in one place.  A model is considered capable if
    either signal is present; ``mandatory`` is meaningful only for capable
    models.
    """
    parameters = settings.get("supported_parameters") or []
    if not isinstance(parameters, (list, tuple, set)):
        parameters = []
    metadata = settings.get("reasoning")
    metadata_supports = bool(metadata) if isinstance(metadata, dict) else False
    supports = "reasoning" in parameters or metadata_supports
    mandatory = bool(metadata.get("mandatory")) if supports and isinstance(metadata, dict) else False
    return {
        "supports_reasoning": bool(supports),
        "reasoning_mandatory": bool(mandatory),
    }


def model_configuration(saved, profile=None):
    profiles = saved.get('model_profiles') or {}
    selected = profiles.get(profile if profile in PROFILE_IDS else DEFAULT_PROFILE) if profile is not None else None
    # Missing assignments inherit the default, including all capability metadata.
    return selected if isinstance(selected, dict) and selected.get('model') else saved


def public_model_capabilities(configuration):
    return {'model': configuration.get('model') or DEFAULT_MODEL, **reasoning_capabilities(configuration), 'web_search_supported': False}


async def current_settings(profile: str | None = None) -> dict:
    saved = await db.settings.find_one({"_id": "ai"}) or {}
    key = configured_key(saved)
    # Metadata/capability reads need no SDK client or network connection.
    _request_key.set(key)
    selected = model_configuration(saved, profile)
    parameters = selected.get("supported_parameters", DEFAULT_PARAMETERS)
    if not isinstance(parameters, list):
        parameters = list(parameters) if isinstance(parameters, (tuple, set)) else list(DEFAULT_PARAMETERS)
    reasoning = selected.get("reasoning")
    if reasoning is not None and not isinstance(reasoning, dict):
        reasoning = None
    return {
        "provider": "Local" if AI_PROVIDER == "local" else "OpenRouter",
        "base_url": BASE_URL,
        "model": selected.get("model") or DEFAULT_MODEL,
        "model_revision": int(saved.get('model_revision') or 0),
        "profile_models": {name: (saved.get('model_profiles') or {}).get(name, {}).get('model', '') for name in PROFILE_IDS},
        "profile_capabilities": {name: public_model_capabilities(model_configuration(saved, name)) for name in PROFILE_IDS},
        "key_configured": bool(key),
        "connection_revision": int(saved.get('connection_revision') or 0),
        "key_source": 'local' if AI_PROVIDER == 'local' else 'admin' if saved.get('provider_secret') else 'environment',
        "key_reentry_required": bool(AI_PROVIDER != 'local' and saved.get('provider_secret') and not key),
        "context_length": selected.get("context_length") or (32768 if AI_PROVIDER == "local" else 131072),
        "max_completion_tokens": selected.get("max_completion_tokens") or 8192,
        "supported_parameters": parameters,
        # Saved catalog metadata lets future requests survive an admin model
        # change without a second catalog call.  It contains no credentials.
        "reasoning": reasoning,
        "updated_at": saved.get("updated_at"),
    }


async def validate_catalog_model(model: str) -> dict:
    """Consult the public catalog; never spend generation credits to save a setting."""
    try:
        async with httpx.AsyncClient(timeout=20) as http:
            response = await http.get(BASE_URL + "/models")
            response.raise_for_status()
            catalog = response.json().get("data", [])
    except (httpx.HTTPError, ValueError, TypeError, AttributeError):
        raise HTTPException(503, "تعذّر الاتصال بخدمة النماذج المحلية. لم تُغيّر الإعدادات." if AI_PROVIDER == "local" else "تعذّر التحقق من كتالوج OpenRouter. لم تُغيّر الإعدادات؛ حاول لاحقًا.")
    selected = next((item for item in catalog if item.get("id") == model), None)
    if selected is None:
        raise HTTPException(400, "النموذج غير مثبت على الخادم. نزّله عبر Ollama أولًا." if AI_PROVIDER == "local" else "اسم النموذج غير موجود في كتالوج OpenRouter. انسخ المعرّف الكامل provider/model.")
    architecture = selected.get("architecture") or {}
    if "text" not in architecture.get("input_modalities", ["text"]):
        raise HTTPException(400, "هذا النموذج لا يدعم رسائل الدردشة النصية.")
    if "text" not in architecture.get("output_modalities", ["text"]):
        raise HTTPException(400, "اختر نموذجًا يولّد النصوص.")
    provider = selected.get("top_provider") or {}
    reasoning = selected.get("reasoning")
    if reasoning is not None and not isinstance(reasoning, dict):
        reasoning = None
    parameters = selected.get("supported_parameters", DEFAULT_PARAMETERS)
    if not isinstance(parameters, list):
        parameters = list(parameters) if isinstance(parameters, (tuple, set)) else list(DEFAULT_PARAMETERS)
    return {
        "model": model,
        "context_length": int(selected.get("context_length") or provider.get("context_length") or (32768 if AI_PROVIDER == "local" else 8192)),
        "max_completion_tokens": int(provider.get("max_completion_tokens") or 8192),
        "supported_parameters": parameters,
        "reasoning": reasoning,
    }


@capabilities_router.get("/capabilities")
async def get_ai_capabilities(_: dict = Depends(current_user)):
    """Authenticated, credential-free capability discovery for the chat UI."""
    settings = await current_settings()
    return {
        "model": settings["model"],
        **reasoning_capabilities(settings),
        "web_search_supported": False,
        **({'profiles': settings['profile_capabilities']} if 'profile_capabilities' in settings else {}),
    }


@router.get("")
async def get_ai_settings(_: dict = Depends(require_permission("ai_models"))):
    return await current_settings()


@router.put("")
async def update_ai_settings(body: ModelSettingsBody, user: dict = Depends(require_permission("ai_models"))):
    saved = await db.settings.find_one({'_id': 'ai'}) or {}
    revision = int(saved.get('model_revision') or 0)
    if body.model_revision is not None and revision != body.model_revision:
        raise HTTPException(409, 'تغيّرت إعدادات النماذج. حدّث الصفحة قبل الحفظ.')
    requested = dict.fromkeys([body.model, *(model for model in (body.profile_models or {}).values() if model)])
    validated = dict(zip(requested, await asyncio.gather(*(validate_catalog_model(model) for model in requested))))
    setting = dict(validated[body.model])
    if body.profile_models is not None:
        profiles = dict(saved.get('model_profiles') or {})
        for profile, model in body.profile_models.items():
            if model: profiles[profile] = {key: validated[model].get(key) for key in MODEL_FIELDS}
            else: profiles.pop(profile, None)
        setting['model_profiles'] = profiles
    setting.update(model_revision=revision + 1, updated_at=datetime.now(timezone.utc).isoformat(), updated_by=user["_id"])
    query = {'_id': 'ai', 'model_revision': revision if 'model_revision' in saved else {'$exists': False}}
    try:
        result = await db.settings.update_one(query, {"$set": setting}, upsert=not bool(saved))
    except DuplicateKeyError:
        raise HTTPException(409, 'تغيّرت إعدادات النماذج. حدّث الصفحة قبل الحفظ.')
    if saved and not result.modified_count:
        raise HTTPException(409, 'تغيّرت إعدادات النماذج. حدّث الصفحة قبل الحفظ.')
    return await current_settings()


class ConnectionBody(BaseModel):
    revision: int = Field(default=0, ge=0)
    api_key: SecretStr = SecretStr('')


def checked_key(value):
    value = value.strip()
    if not 16 <= len(value) <= 500 or any(ord(c) < 33 or ord(c) > 126 for c in value):
        raise HTTPException(400, 'أدخل مفتاح API صالحًا بلا مسافات أو أسطر إضافية.')
    return value


async def inspect_connection(key, model):
    """Read-only provider endpoints; never send a completion or charge a wallet."""
    if not key:
        raise HTTPException(400, 'لم يُضبط مفتاح النموذج بعد.')
    try:
        async with httpx.AsyncClient(timeout=20, follow_redirects=False) as http:
            if AI_PROVIDER != 'local':
                if BASE_URL != 'https://openrouter.ai/api/v1':
                    raise HTTPException(400, 'اختبار المفتاح متاح لاتصال OpenRouter الرسمي فقط. اتصال الخادم المخصص محفوظ كما هو.')
                response = await http.get(BASE_URL + '/key', headers={'Authorization': 'Bearer ' + key})
                if response.status_code in (401, 403):
                    raise HTTPException(400, 'رفض المزوّد المفتاح. تحقّق منه ومن صلاحياته.')
                response.raise_for_status()
                account = response.json().get('data')
                if not isinstance(account, dict):
                    raise ValueError()
            else:
                account = {}
            response = await http.get(BASE_URL + '/models')
            response.raise_for_status()
            catalog = response.json().get('data')
            if not isinstance(catalog, list):
                raise ValueError()
        model_available = any(isinstance(item, dict) and item.get('id') == model for item in catalog)
        warning = None if model_available else 'model_unavailable'
        if AI_PROVIDER != 'local':
            free = account.get('free_model_daily_requests')
            if model.endswith(':free') and isinstance(free, dict) and free.get('remaining') == 0:
                warning = 'free_limit'
            elif not model.endswith(':free') and account.get('limit_remaining') == 0:
                warning = 'key_limit'
        return {'key_valid': True, 'model_available': model_available, 'warning': warning,
                'ready': model_available and warning is None, 'checked_at': datetime.now(timezone.utc).isoformat()}
    except HTTPException:
        raise
    except httpx.HTTPStatusError as error:
        if error.response.status_code == 429:
            raise HTTPException(429, 'وصل المزوّد إلى حد الطلبات. انتظر قليلًا ثم أعد الفحص.')
        raise HTTPException(502, 'تعذّر فحص اتصال النموذج. لم تُغيّر الإعدادات.')
    except (httpx.HTTPError, ValueError, TypeError, AttributeError):
        raise HTTPException(502, 'تعذّر الاتصال بخدمة النموذج. لم تُغيّر الإعدادات.')


@router.post('/connection/test')
async def test_connection(body: ConnectionBody, _=Depends(require_super_admin)):
    saved = await db.settings.find_one({'_id': 'ai'}) or {}
    supplied = body.api_key.get_secret_value()
    key = checked_key(supplied) if supplied else configured_key(saved)
    return await inspect_connection(key, saved.get('model') or DEFAULT_MODEL)


@router.put('/connection')
async def save_connection(body: ConnectionBody, user=Depends(require_super_admin)):
    if AI_PROVIDER == 'local':
        raise HTTPException(400, 'الاتصال المحلي لا يحتاج مفتاح API خارجيًا.')
    saved = await db.settings.find_one({'_id': 'ai'}) or {}
    if int(saved.get('connection_revision') or 0) != body.revision:
        raise HTTPException(409, 'تغيّر إعداد الاتصال. حدّث الصفحة قبل الحفظ.')
    key = checked_key(body.api_key.get_secret_value())
    report = await inspect_connection(key, saved.get('model') or DEFAULT_MODEL)
    query = {'_id': 'ai', 'connection_revision': body.revision if 'connection_revision' in saved else {'$exists': False}}
    values = {'provider_secret': credential_cipher().encrypt(key.encode()).decode(),
              'connection_revision': body.revision + 1, 'connection_updated_by': user['_id'],
              'connection_updated_at': datetime.now(timezone.utc).isoformat()}
    try:
        result = await db.settings.update_one(query, {'$set': values}, upsert=not bool(saved))
    except DuplicateKeyError:
        raise HTTPException(409, 'تغيّر إعداد الاتصال. حدّث الصفحة قبل الحفظ.')
    if saved and not result.modified_count:
        raise HTTPException(409, 'تغيّر إعداد الاتصال. حدّث الصفحة قبل الحفظ.')
    return {'settings': await current_settings(), 'test': report}


async def claim_generation(uid: str) -> str:
    """A durable CAS lease protects each user's budget across server processes.

    SQL compares expiry explicitly; no database TTL worker is required. An
    expired row is replaced atomically and cannot block a new generation.
    """
    now = datetime.now(timezone.utc)
    lease_id = secrets.token_hex(16)
    try:
        await db.ai_request_leases.find_one_and_update(
            {"_id": uid, "$or": [{"expires_at": {"$lte": now}}, {"expires_at": {"$exists": False}}]},
            {"$set": {"lease_id": lease_id, "expires_at": now + timedelta(seconds=240)}},
            upsert=True,
        )
    except DuplicateKeyError:
        raise HTTPException(409, "هناك رد جارٍ لهذا الحساب. انتظر اكتماله أو أوقفه أولًا.")
    return lease_id


async def release_generation(uid: str, lease_id: str):
    await db.ai_request_leases.delete_one({"_id": uid, "lease_id": lease_id})


def provider_error(error: Exception) -> dict:
    """Map provider failures to safe app messages; never serialize raw upstream bodies."""
    status = getattr(error, "status_code", None)
    code = "provider_error"
    message = "تعذّر إكمال الرد من مزوّد الذكاء الاصطناعي. حاول لاحقًا."
    if status in (401, 403):
        code, message = "provider_auth", "تعذّر الاتصال بالمزوّد. يُرجى من الإدارة التحقق من مفتاح OpenRouter وصلاحياته."
    elif status == 402:
        code, message = "provider_credits", "خدمة النموذج غير متاحة بسبب رصيد حساب المزوّد. تواصل مع الإدارة."
    elif status == 429:
        code, message = "provider_rate_limit", "مزوّد النموذج مشغول حاليًا. حاول بعد قليل."
    elif status in (400, 404):
        code, message = "provider_model", "تعذّر تشغيل النموذج المحدد. يُرجى من الإدارة التحقق من النموذج والإعدادات."
    elif isinstance(error, (httpx.TimeoutException, TimeoutError)) or type(error).__name__ == "APITimeoutError":
        code, message = "provider_timeout", "انتهت مهلة الرد من المزوّد. حاول مرة أخرى."
    return {"code": code, "message": message}
