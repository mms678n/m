#!/usr/bin/env python3
"""Finite, additive schema preparation. No Mongo data import or account reset."""
import argparse
import asyncio
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

from dotenv import load_dotenv
load_dotenv(ROOT / "backend" / ".env")
load_dotenv(ROOT / ".env")

from persistence import (
    selected_backend, get_database, initialize_database, ping_database,
    verify_database, close_database,
)


async def execute(action):
    try:
        if action == "migrate":
            await initialize_database()
        await ping_database()
        if action == "check":
            await verify_database()
        print(f"Persistence {action}: OK ({selected_backend()}); no legacy data imported")
    finally:
        if get_database() is not None:
            await close_database()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=["migrate", "check", "ping"])
    args = parser.parse_args()
    try:
        asyncio.run(execute(args.action))
    except Exception as error:
        # DB client errors can embed connection details; log only the class.
        print(f"Persistence {args.action} failed ({type(error).__name__}); check server configuration", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
