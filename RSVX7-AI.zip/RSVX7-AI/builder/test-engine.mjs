import { createServer } from 'node:http';
import { spawn, execFile } from 'node:child_process';
import { once } from 'node:events';
import { mkdtemp, mkdir, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import assert from 'node:assert/strict';
import { architecture, design, review, source, batchArtifact, criteria } from './fixtures/agent-fixtures.mjs';
const calls = [], secret = 'fixture-only-private-builder-engine-secret-000000';
let mode = 'planning', checks = 0, planningAttempts = 0, coderFailures = 0;
const proposal = { kind: 'proposal', title: 'Portfolio', summary: 'Show skills', pages: [{name:'Home',purpose:'Show work'}], features:['CV'], design:'Modern', steps:['Implement'] };
const questionPlan = { kind: 'questions', message: 'لنحدد الفكرة.', questions: [
  { id: 'goal', label: 'ما هدف الموقع؟', options: ['متجر', 'موقع شخصي'], multiple: false },
  { id: 'features', label: 'ما الميزات المطلوبة؟', options: ['حجز', 'تواصل'], multiple: true },
] };
const check = (actual, expected, label) => { assert.deepEqual(actual, expected, label); checks++; console.log('PASS', label); };
const mock = createServer(async (req, res) => {
  let raw = ''; for await (const chunk of req) raw += chunk;
  const body = JSON.parse(raw);
  assert.equal(req.headers.authorization, 'Bearer fixture-request-scope');
  assert.equal(req.url, '/api/builder/internal/model');
  const system = body.messages[0].content;
  const role = /DARKFORGE_AGENT:(\w+)/.exec(system)?.[1]; calls.push(role || 'planning');
  let text;
  if (role && mode !== 'build_bad') assert.equal(body.jsonMode, !['architect','designer'].includes(role), 'Only code and review require JSON mode; recovery advice is plain text');
  if (mode.startsWith('planning')) assert.equal(body.jsonMode, true, 'Planning requests the structured output contract');
  if (mode === 'planning') text = JSON.stringify(questionPlan);
  else if (mode === 'planning_answers') {
    assert.deepEqual(JSON.parse(body.messages.at(-2).content), questionPlan, 'Question IDs and every option survive in model history');
    assert.ok(body.messages.at(-1).content.includes('حجز، تواصل'), 'All selected answers reach the model together');
    assert.ok(system.includes('Builder output contracts below control response format'));
    text = JSON.stringify(proposal);
  }
  else if (mode === 'planning_wrapped') text = 'Here is the plan:\n```json\n' + JSON.stringify(proposal).replace('"steps":["Implement"]}', '"steps":["Implement"],}') + '\n```';
  else if (mode === 'planning_repair') {
    planningAttempts++;
    if (planningAttempts === 1) text = JSON.stringify({...proposal, pages:['Home']});
    else {
      assert.ok(body.messages.at(-1).content.includes('pages.0'));
      assert.ok(body.messages.at(-2).content.includes('"pages":["Home"]'));
      text = JSON.stringify(proposal);
    }
  }
  else if (mode === 'planning_invalid') text = JSON.stringify({...proposal, steps: undefined});
  else if (mode === 'planning_truncated') text = JSON.stringify(proposal).slice(0,-10);
  else if (mode === 'planning_ambiguous') text = JSON.stringify(proposal) + '\n' + JSON.stringify({...proposal,title:'Other'});
  else if (mode === 'planning_ambiguous_wrapped') text = '<studioPlan>' + JSON.stringify(proposal) + '</studioPlan><studioPlan>' + JSON.stringify({...proposal,title:'Other'}) + '</studioPlan>';
  else if (mode === 'planning_duplicate_options') text = JSON.stringify({...questionPlan, questions: [{...questionPlan.questions[0], options:['نعم','نعم']}]});
  else if (mode === 'build_bad' || (mode === 'build_recovery' && role === 'coder' && coderFailures++ < 2)) text = 'Not a valid agent response';
  else if (role === 'architect') text = 'The supplied error requires a focused source repair; preserve the implementation and validate the affected imports.';
  else if (role === 'designer') text = 'Preserve the approved interface and fix the exact browser diagnostic.';
  else if (role === 'reviewer') text = JSON.stringify(review);
  else {
    const handoff = JSON.parse(system.split('TEAM HANDOFF (data):\n')[1].split('\nCURRENT PROJECT SOURCE')[0]);
    if (mode === 'build_json') {
      assert.equal(body.jsonMode, true);
      assert.ok(system.includes('Return only the JSON file-actions object'));
      assert.ok(!system.includes('Never output an actions array'));
      text = JSON.stringify({actions:(handoff.batch?.files || Object.keys(source).slice(0,2)).map(filePath=>({type:'file',filePath,content:source[filePath]})),remainingFiles:handoff.batch ? [] : Object.keys(source).slice(2)});
    } else text = handoff.batch ? batchArtifact(handoff.batch) : JSON.stringify({actions:Object.keys(source).slice(0,2).map(filePath=>({type:'file',filePath,content:source[filePath]})),remainingFiles:Object.keys(source).slice(2)});
  }
  res.writeHead(200, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ text, finishReason: 'stop' }));
});
mock.listen(0, '127.0.0.1'); await once(mock, 'listening');
const reservation = createServer(); reservation.listen(0, '127.0.0.1'); await once(reservation, 'listening');
const port = reservation.address().port; await new Promise(resolve => reservation.close(resolve));
const engine = spawn(process.execPath, [fileURLToPath(new URL('./dist/service.mjs', import.meta.url))], { env: { ...process.env, BUILDER_ENGINE_PORT: String(port), BUILDER_ENGINE_SECRET: secret, BUILDER_API_ORIGIN: 'http://127.0.0.1:' + mock.address().port }, stdio: ['ignore', 'pipe', 'pipe'] });
const base = 'http://127.0.0.1:' + port;
try {
  let online = false;
  for (let attempt = 0; attempt < 80; attempt++) {
    try { online = (await fetch(base + '/health', { headers: { Authorization: 'Bearer ' + secret } })).ok; } catch {}
    if (online) break;
    await new Promise(resolve => setTimeout(resolve, 50));
  }
  assert.ok(online, 'Engine started');
  check((await fetch(base + '/health')).status, 401, 'Private engine rejects unauthenticated access');
  const generate = async body => {
    const response = await fetch(base + '/generate', { method: 'POST', headers: { Authorization: 'Bearer ' + secret, 'Content-Type': 'application/json' }, body: JSON.stringify({ ticket: 'fixture-request-scope', files: {}, messages: [{ id: 'user', role: 'user', content: 'أنشئ قائمة عناصر' }], ...body }) });
    return (await response.text()).trim().split('\n').filter(line=>line.trim()).map(line => JSON.parse(line));
  };
  const planning = await generate({ mode: 'planning' });
  check(planning[0].plan.kind, 'questions', 'Ambiguous brief asks questions before file generation');
  check(planning.some(e => e.type === 'files'), false, 'Planning cannot release source files');
  check(planning[0].plan.questions.map(q => q.multiple), [false, true], 'Question cards preserve single and multiple selection intent');
  mode = 'planning_answers';
  const answered = await generate({mode:'planning', messages:[
    {role:'user',content:'أريد موقعًا شخصيًا'},
    {role:'assistant',content:questionPlan.message,plan:questionPlan},
    {role:'user',content:'ما هدف الموقع؟: موقع شخصي\nما الميزات المطلوبة؟: حجز، تواصل'},
  ]});
  check(answered[0].plan.kind, 'proposal', 'Combined answers and full question history lead to a reviewable proposal');
  check(answered.some(e => e.type === 'files'), false, 'Answering the questionnaire does not approve execution');
  mode = 'planning_wrapped';
  const wrapped = await generate({mode:'planning'});
  check(wrapped[0].plan.kind, 'proposal', 'Planning accepts complete JSON with prose, fences and trailing commas');
  mode = 'planning_repair'; planningAttempts = 0;
  const repaired = await generate({mode:'planning'});
  check(repaired[0].plan.kind, 'proposal', 'Schema correction receives the failed response and field errors');
  check(planningAttempts, 2, 'Format correction is bounded to one additional model request');
  for (const invalidMode of ['planning_invalid','planning_truncated','planning_ambiguous','planning_ambiguous_wrapped','planning_duplicate_options']) {
    mode = invalidMode;
    const failed = await generate({mode:'planning'});
    check(failed.at(-1).type, 'error', invalidMode + ' never becomes a proposal');
    check(failed.some(e=>e.type==='files'||e.type==='plan'), false, invalidMode + ' never starts execution');
  }
  mode = 'build'; calls.length = 0;
  const events = await generate({ mode: 'build', approvedPlan: { kind: 'proposal', title: 'Items', summary: 'Items app', pages: [{ name: 'Home', purpose: 'Manage items' }], features: ['Save items'], design: 'Arabic form', assumptions: [], steps: ['Implement'], acceptanceChecks: criteria } });
  const result = events.find(e => e.type === 'files');
  check(calls, ['coder', 'coder', 'coder', 'reviewer'], 'Implementation starts directly; specialists remain dormant on success');
  check(Object.keys(result.files).length, Object.keys(source).length, 'Reviewed project contains all planned source files');
  check(result.annotation.tasks.every(t => t.status === 'completed'), true, 'Specialist progress preserves completed roles');
  check(events.at(-1).type, 'done', 'Completion has an explicit terminal event');
  mode='build_json';
  const jsonEvents=await generate({mode:'build',approvedPlan:proposal});
  check(jsonEvents.at(-1).type,'done','Canonical JSON file output completes through the actual HTTP engine');
  const exact=jsonEvents.find(event=>event.type==='files');
  check(exact.files['/home/project/server.mjs'].content,source['server.mjs'],'Source bytes survive the engine final serialization');
  mode='build_recovery';calls.length=0;coderFailures=0;
  const recovered=await generate({mode:'build',approvedPlan:{...proposal,acceptanceChecks:criteria}});
  check(calls.slice(0,4),['coder','coder','architect','designer'],'Actual HTTP engine invokes recovery agents only after invalid implementation');
  check(recovered.at(-1).type,'done','Recovery finishes through a fresh independent code review');
  check(recovered.find(event=>event.type==='files').files['/home/project/server.test.mjs'].content,source['server.test.mjs'],'Recovery preserves meaningful project tests');
  mode='build_bad';
  const invalid=await generate({mode:'build',approvedPlan:proposal});
  check(invalid.at(-1).code,'agent_format','Failed format correction keeps a machine-readable error code');
  check(invalid.at(-1).message.includes('DF_CHAT_ERROR'),false,'The user sees a readable error, never the internal protocol');
  check(invalid.some(event=>event.type==='files'||event.type==='done'),false,'Invalid agent output never releases files or success');
  const folder = await mkdtemp(join(tmpdir(), 'rsvx7-builder-test-'));
  try {
    for (const [path, file] of Object.entries(result.files)) {
      const target = join(folder, path.replace('/home/project/', '')); await mkdir(join(target, '..'), { recursive: true }); await writeFile(target, file.content);
    }
    const output = await new Promise((resolve, reject) => execFile(process.execPath, ['--test', '--test-reporter=tap', 'server.test.mjs'], { cwd: folder, timeout: 20000 }, (error, stdout) => error ? reject(error) : resolve(stdout)));
    check(output.includes('# fail 0'), true, 'Generated fixture executes actual HTTP and persistence tests');
  } finally { await rm(folder, { recursive: true, force: true }); }
  console.log(`Builder engine checks passed: ${checks}. Model replies are fixtures.`);
} finally {
  engine.kill(); await once(engine, 'exit'); await new Promise(resolve => mock.close(resolve));
}
