"""Mock-only reasoning protocol regressions; never call a model or live database."""
import asyncio
import json
import os
import sys
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import ValidationError

BACKEND = Path(__file__).resolve().parents[1] / "backend"
if str(BACKEND) not in sys.path:
    sys.path.insert(0, str(BACKEND))
os.environ.setdefault("MONGO_URL", "mongodb://127.0.0.1:27017")
os.environ.setdefault("DB_NAME", "rsvx7ai_test_reasoning")
os.environ.setdefault("JWT_SECRET", "test-only-reasoning-secret")

import ai_settings  # noqa: E402
import auth  # noqa: E402
import server  # noqa: E402
import workspace  # noqa: E402


def run(awaitable):
    return asyncio.run(awaitable)


class FakeStream:
    def __init__(self, chunks):
        self.chunks = chunks
        self.close = AsyncMock()

    async def __aiter__(self):
        for chunk in self.chunks:
            yield chunk


def chunk(delta=None, finish=None, usage=None):
    choice = SimpleNamespace(delta=delta, finish_reason=finish)
    return SimpleNamespace(choices=[choice] if delta is not None or finish else [], usage=usage)


def usage(prompt=12, completion=5, cached=0, reasoning=2):
    return SimpleNamespace(
        prompt_tokens=prompt,
        completion_tokens=completion,
        prompt_tokens_details=SimpleNamespace(cached_tokens=cached),
        completion_tokens_details=SimpleNamespace(reasoning_tokens=reasoning),
    )


def patch_chat(monkeypatch, stream, settings):
    create = AsyncMock(return_value=stream)
    monkeypatch.setattr(
        server,
        "openrouter_client",
        SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))),
    )
    monkeypatch.setattr(server, "current_settings", AsyncMock(return_value=settings))
    monkeypatch.setattr(server, "require_membership", AsyncMock())
    monkeypatch.setattr(server, "check_can_afford", AsyncMock())
    monkeypatch.setattr(server, "claim_generation", AsyncMock(return_value="reasoning-lease"))
    monkeypatch.setattr(server, "release_generation", AsyncMock())
    charge = AsyncMock(return_value={"billed_total": 1})
    monkeypatch.setattr(server, "charge_user", charge)
    monkeypatch.setattr(
        server,
        "db",
        SimpleNamespace(users=SimpleNamespace(find_one=AsyncMock(return_value={"token_balance": 99}))),
    )
    return create, charge


def collect_events(response):
    async def collect():
        body = "".join([part async for part in response.body_iterator])
        events = []
        for line in body.splitlines():
            if not line.startswith("data: "):
                continue
            payload = line[6:]
            if payload != "[DONE]":
                events.append(json.loads(payload))
        return events

    return run(collect())


def test_capabilities_are_authenticated_exact_and_credential_free(monkeypatch):
    monkeypatch.setattr(
        ai_settings,
        "current_settings",
        AsyncMock(
            return_value={
                "model": "nousresearch/hermes-3-llama-3.1-405b",
                "supported_parameters": ["max_tokens"],
                "reasoning": None,
            }
        ),
    )
    app = FastAPI()
    app.include_router(ai_settings.capabilities_router)
    app.dependency_overrides[auth.current_user] = lambda: {"_id": "u"}
    with TestClient(app) as client:
        response = client.get("/api/ai/capabilities")
        assert response.status_code == 200
        assert response.json() == {
            "model": "nousresearch/hermes-3-llama-3.1-405b",
            "supports_reasoning": False,
            "reasoning_mandatory": False,
            "web_search_supported": False,
        }
    unauthenticated = FastAPI()
    unauthenticated.include_router(ai_settings.capabilities_router)
    with TestClient(unauthenticated) as client:
        assert client.get("/api/ai/capabilities").status_code == 401


def test_reasoning_is_conditional_and_streams_separate_events(monkeypatch):
    stream = FakeStream(
        [
            chunk(SimpleNamespace(reasoning="draft ", content=None)),
            chunk(SimpleNamespace(reasoning_content="answer-plan ", content=None)),
            chunk(SimpleNamespace(reasoning_details=[
                SimpleNamespace(type="reasoning.encrypted", data="secret"),
                SimpleNamespace(type="reasoning.text", text="details"),
            ], content=None)),
            chunk(SimpleNamespace(content="visible"), finish="stop"),
            chunk(usage=usage()),
        ]
    )
    settings = {
        "model": "deepseek/deepseek-v4.1-flash",
        "context_length": 131072,
        "max_completion_tokens": 1024,
        "supported_parameters": ["reasoning"],
        "reasoning": {"mandatory": False},
    }
    create, charge = patch_chat(monkeypatch, stream, settings)

    response = run(
        server.chat_stream(
            server.ChatBody(messages=[{"role": "user", "content": "hello"}], deep_think=True),
            {"_id": "u", "role": "super_admin"},
        )
    )
    events = collect_events(response)
    payloads = [event for event in events if "r" in event or "t" in event]
    assert [next(iter(event)) for event in payloads] == ["r", "r", "r", "t"]
    assert "secret" not in json.dumps(events)
    phases = [event["status"]["phase"] for event in events if "status" in event]
    assert phases[:3] == ["connecting", "thinking", "streaming"]
    assert create.call_args.kwargs["extra_body"] == {
        "reasoning": {"enabled": True, "exclude": False}
    }
    # OpenRouter completion_tokens already includes reasoning tokens.
    assert charge.await_args.kwargs["completion_tokens"] == 5
    assert stream.close.await_count == 1
    server.release_generation.assert_awaited_once_with("u", "reasoning-lease")


def test_hermes_ignores_deep_think_without_reasoning_request(monkeypatch):
    stream = FakeStream([chunk(SimpleNamespace(content="OK"), finish="stop"), chunk(usage=usage(completion=1, reasoning=0))])
    settings = {
        "model": "nousresearch/hermes-3-llama-3.1-405b",
        "context_length": 131072,
        "max_completion_tokens": 1024,
        "supported_parameters": ["max_tokens"],
        "reasoning": None,
    }
    create, _ = patch_chat(monkeypatch, stream, settings)
    response = run(server.chat_stream(server.ChatStreamRequest(
        messages=[{"role": "user", "content": "hello"}], deep_think=True
    ), {"_id": "u", "role": "super_admin"}))
    events = collect_events(response)
    assert any(event.get("t") == "OK" for event in events)
    assert create.call_args.kwargs["extra_body"] is None


def test_reasoning_only_length_preserves_finish_and_fallback_usage(monkeypatch):
    stream = FakeStream([
        chunk(SimpleNamespace(reasoning_content="long internal work", content=None), finish="length"),
    ])
    settings = {
        "model": "deepseek/deepseek-v4.1-flash",
        "context_length": 131072,
        "max_completion_tokens": 1024,
        "supported_parameters": ["reasoning"],
        "reasoning": {"mandatory": False},
    }
    _, charge = patch_chat(monkeypatch, stream, settings)
    monkeypatch.setattr(server, "estimate_messages_tokens", lambda messages: len(messages[0]["content"]))
    response = run(server.chat_stream(server.ChatStreamRequest(
        messages=[{"role": "user", "content": "hello"}], deep_think=True
    ), {"_id": "u", "role": "super_admin"}))
    events = collect_events(response)
    assert not any("t" in event for event in events)
    assert {"finish": "length"} in events
    finalizing = next(event["status"] for event in events if event.get("status", {}).get("phase") == "finalizing")
    assert finalizing["content_emitted"] is False
    assert charge.await_args.kwargs["completion_tokens"] == len("long internal work")


def test_workspace_reasoning_metadata_is_optional_and_assistant_only():
    assistant = workspace.MessageCreate(
        id="m_assistant",
        role="assistant",
        content="answer",
        reasoning="private reasoning",
        reasoning_duration_ms=600000,
        finish_reason="length",
        reasoning_started_at="2026-10-04T12:00:00+00:00",
    )
    user = workspace.MessageCreate(
        id="m_user",
        role="user",
        content="question",
        reasoning="must not persist",
    )
    assert workspace._assistant_metadata(assistant)["reasoning"] == "private reasoning"
    assert workspace._assistant_metadata(user) == {}
    with pytest.raises(ValidationError):
        workspace.MessageCreate(id="too-long", role="assistant", content="x", reasoning="x" * 131073)
    with pytest.raises(ValidationError):
        workspace.MessageCreate(id="bad-duration", role="assistant", content="x", reasoning_duration_ms=-1)
    with pytest.raises(ValidationError):
        workspace.MessageCreate(id="bad-time", role="assistant", content="x", reasoning_started_at="not-a-date")

@pytest.mark.parametrize('tail',[
    chunk(SimpleNamespace(content='late content')),
    chunk(SimpleNamespace(reasoning_content='late reasoning')),
    chunk(SimpleNamespace(content=None),finish='length'),
])
def test_conflicting_events_after_finish_do_not_bill_or_report_success(monkeypatch,tail):
    stream=FakeStream([chunk(SimpleNamespace(content='answer'),finish='stop'),tail,chunk(usage=usage())])
    _,charge=patch_chat(monkeypatch,stream,{
        'model':'fixture/stream','context_length':32000,'max_completion_tokens':512,
        'supported_parameters':[],'reasoning':None,
    })
    response=run(server.chat_stream(server.ChatStreamRequest(messages=[{'role':'user','content':'hello'}]),{'_id':'u','role':'super_admin'}))
    events=collect_events(response)
    assert any('error' in event for event in events)
    assert not any('finish' in event for event in events)
    charge.assert_not_awaited()
    assert stream.close.await_count==1
    server.release_generation.assert_awaited_once_with('u','reasoning-lease')
