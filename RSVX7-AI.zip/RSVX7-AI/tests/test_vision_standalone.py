"""Direct vision protocol and credential isolation, without paid provider requests."""
import asyncio
import base64
import io
from types import SimpleNamespace
from unittest.mock import AsyncMock

from PIL import Image
import vision


def picture():
    output = io.BytesIO()
    Image.new('RGBA', (4, 4), (255, 0, 0, 255)).save(output, 'PNG')
    return output.getvalue()


def test_disabled_vision_does_not_create_provider(monkeypatch):
    monkeypatch.delenv('VISION_MODEL', raising=False)
    monkeypatch.setattr(vision, 'AsyncOpenAI', lambda **kw: (_ for _ in ()).throw(AssertionError('Unexpected provider call')))
    assert asyncio.run(vision.describe_image(picture())) == ''


def test_dedicated_vision_uses_multimodal_protocol_and_closes_client(monkeypatch):
    for key, value in {'VISION_MODEL':'fixture/vision','VISION_API_KEY':'test-private','VISION_BASE_URL':'https://provider.invalid/v1'}.items():
        monkeypatch.setenv(key, value)
    completion = AsyncMock(return_value=SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content='وصف الصورة'))]))
    client = SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=completion)),close=AsyncMock())
    configs = []
    def connect(**kwargs):
        configs.append(kwargs)
        return client
    monkeypatch.setattr(vision, 'AsyncOpenAI', connect)
    assert asyncio.run(vision.describe_image(picture())) == 'وصف الصورة'
    assert configs[0]['base_url'] == 'https://provider.invalid/v1'
    payload = completion.await_args.kwargs
    assert payload['model'] == 'fixture/vision'
    encoded = payload['messages'][1]['content'][1]['image_url']['url']
    assert encoded.startswith('data:image/jpeg;base64,')
    assert Image.open(io.BytesIO(base64.b64decode(encoded.split(',')[1]))).format == 'JPEG'
    client.close.assert_awaited_once()


def test_separate_endpoint_without_key_never_reuses_chat_credentials(monkeypatch):
    monkeypatch.setenv('VISION_MODEL','fixture/vision')
    monkeypatch.setenv('VISION_BASE_URL','https://provider.invalid/v1')
    monkeypatch.delenv('VISION_API_KEY',raising=False)
    monkeypatch.setattr(vision, 'AsyncOpenAI', lambda **kw: (_ for _ in ()).throw(AssertionError('Unexpected provider call')))
    assert asyncio.run(vision.describe_image(picture())) == ''


def test_provider_failure_does_not_return_sensitive_error(monkeypatch, caplog):
    monkeypatch.setenv('VISION_MODEL','fixture/vision')
    monkeypatch.setenv('VISION_API_KEY','test-private')
    completion = AsyncMock(side_effect=RuntimeError('private-provider-error-secret'))
    client = SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=completion)),close=AsyncMock())
    monkeypatch.setattr(vision, 'AsyncOpenAI', lambda **kw: client)
    assert asyncio.run(vision.describe_image(picture())) == ''
    assert 'private-provider-error-secret' not in caplog.text
    client.close.assert_awaited_once()
