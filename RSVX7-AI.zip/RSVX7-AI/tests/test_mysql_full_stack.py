"""Opt-in production-mode SQL runtime; no managed DB/provider credentials/data."""
import asyncio
import os
import secrets
import socket
import subprocess
import tempfile
import time
from pathlib import Path

import pytest
import requests

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.skipif(os.environ.get("RUN_MYSQL_TESTS") != "1", reason="Opt-in local SQL runtime")
def test_sql_production_runtime_persists_accounts_chat_and_private_files_after_restart():
    import sys
    sys.path.insert(0, str(ROOT / "backend"))
    from mysql_repository import MySQLDatabase
    from sql_schema import COLLECTION_TABLES
    url = "mysql://root@127.0.0.1:3307/rsvx7_test_mysql_e2e"
    async def prepare():
        db = MySQLDatabase(url, allow_local_plaintext=True)
        try:
            await db.initialize()
            for name in COLLECTION_TABLES:
                await getattr(db, name).delete_many({})
        finally:
            await db.close()
    asyncio.run(prepare())
    password, rotated_password = secrets.token_urlsafe(20), secrets.token_urlsafe(20)
    env = os.environ.copy()
    env.update(DATABASE_URL=url, RSVX7_DATA_BACKEND="mysql", RSVX7_SQL_TEST_ALLOW_PLAINTEXT="1",
               RSVX7_RUNTIME_ENV="production", RSVX7_JWT_SECRET=secrets.token_hex(32),
               JWT_SECRET="platform-alias-not-application-key", COOKIE_SECURE="false",
               OWNER_USERNAME="sql_fixture_owner", RSVX7_MANAGED_OWNER_PASSWORD=password,
               OPENROUTER_API_KEY="", DEEPSEEK_API_KEY="",
               MANUS_API_URL="https://synthetic.invalid", MANUS_API_KEY="fixture-not-live",
               FILE_STORAGE_BACKEND="manus", OPENROUTER_MODEL="nousresearch/hermes-3-llama-3.1-405b")
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    base = f"http://127.0.0.1:{port}"
    with tempfile.TemporaryDirectory(prefix="rsvx7-sql-runtime-") as directory:
        env["SQL_TEST_OBJECT_DIR"] = str(Path(directory) / "objects")
        env["OWNER_CREDENTIALS_FILE"] = str(Path(directory) / "must-not-exist.md")
        log_path = Path(directory) / "runtime.log"
        def start():
            with log_path.open("a") as log:
                process = subprocess.Popen([str(ROOT / ".venv/bin/python"), "-m", "uvicorn", "sql_runtime_fixture:app", "--host", "127.0.0.1", "--port", str(port), "--app-dir", str(ROOT / "tests")], cwd=ROOT, env=env, stdout=log, stderr=log)
            deadline = time.monotonic() + 30
            while time.monotonic() < deadline:
                if process.poll() is not None:
                    raise AssertionError("SQL fixture exited; check startup/migration contract")
                try:
                    response = requests.get(base + "/readyz", timeout=1)
                    if response.status_code == 200:
                        assert response.json()["persistence"] == "mysql"
                        return process
                except requests.RequestException:
                    pass
                time.sleep(0.1)
            process.terminate()
            process.wait(timeout=5)
            raise AssertionError("SQL fixture did not become ready")
        def stop(process):
            process.terminate()
            try: process.wait(timeout=8)
            except subprocess.TimeoutExpired:
                process.kill(); process.wait(timeout=5)
        process = start()
        try:
            session = requests.Session()
            login = session.post(base + "/api/auth/login", json={"username": "sql_fixture_owner", "password": password}, timeout=5)
            assert login.status_code == 200
            session.headers["Authorization"] = "Bearer " + login.json()["token"]
            assert session.get(base + "/api/admin/ai-settings", timeout=5).status_code == 403
            changed = session.post(base + "/api/auth/change-password", json={"old_password": password, "new_password": rotated_password}, timeout=5)
            assert changed.status_code == 200
            session.headers["Authorization"] = "Bearer " + changed.json()["token"]
            settings = session.get(base + "/api/admin/ai-settings", timeout=5)
            assert settings.status_code == 200
            assert settings.json()["model"] == env["OPENROUTER_MODEL"] and "api_key" not in settings.json()
            assert session.get(base + "/api/admin/stats", timeout=5).status_code == 200
            project = session.post(base + "/api/workspace/projects", json={"name": "SQL durable test"}, timeout=5)
            assert project.status_code == 200
            pid = project.json()["_id"]
            conversation = session.post(base + f"/api/workspace/projects/{pid}/conversations", json={"title": "Persistent chat"}, timeout=5).json()
            cid = conversation["_id"]
            turn = session.post(base + f"/api/workspace/conversations/{cid}/turn", json={"messages": [{"id": "m_sql_runtime", "role": "assistant", "content": "Saved partial response"}]}, timeout=5)
            assert turn.status_code == 200
            upload = session.post(base + f"/api/workspace/projects/{pid}/files", files={"file": ("private.txt", b"private persisted bytes", "text/plain")}, timeout=8)
            assert upload.status_code == 200
            fid = upload.json()["_id"]
            assert upload.json()["storage_path"].startswith("manus:")
            assert "payload_encryption" not in upload.json()
            for stored in Path(env["SQL_TEST_OBJECT_DIR"]).iterdir():
                assert b"private persisted bytes" not in stored.read_bytes()
            listed = session.get(base + f"/api/workspace/projects/{pid}/files", timeout=5).json()
            assert all("payload_encryption" not in file for file in listed)
            assert session.get(base + f"/api/workspace/files/{fid}/download", timeout=5).content == b"private persisted bytes"
            assert requests.get(base + f"/api/workspace/files/{fid}/download", timeout=5).status_code == 401
            assert not Path(env["OWNER_CREDENTIALS_FILE"]).exists()
            assert session.post(base + "/api/workspace/migrate", json={"chats": []}, timeout=5).status_code == 409
            # Restart with a different bootstrap secret. Existing owner password
            # and SQL data must remain unchanged; test object bytes survive too.
            stop(process)
            env["RSVX7_MANAGED_OWNER_PASSWORD"] = secrets.token_urlsafe(20)
            process = start()
            relogin = requests.post(base + "/api/auth/login", json={"username": "sql_fixture_owner", "password": rotated_password}, timeout=5)
            assert relogin.status_code == 200
            session.headers["Authorization"] = "Bearer " + relogin.json()["token"]
            data = session.get(base + f"/api/workspace/conversations/{cid}", timeout=5).json()
            assert any(message["content"] == "Saved partial response" for message in data["messages"])
            assert session.get(base + f"/api/workspace/files/{fid}/download", timeout=5).content == b"private persisted bytes"
        finally:
            if process.poll() is None: stop(process)
            asyncio.run(prepare())
