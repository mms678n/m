"""Regression tests for Telegram membership verification.

These tests never call Telegram and never use preview/production data.  The
backend import is intentionally configured for a dedicated local test DB.
"""
import os
import sys
import asyncio
from pathlib import Path

os.environ["DB_NAME"] = "rsvx7ai_test_telegram"
os.environ["MONGO_URL"] = "mongodb://localhost:27017"
os.environ["JWT_SECRET"] = "telegram-test-fixture-secret"

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "backend"))

import pytest
from pydantic import ValidationError

import tg_verify


class MockTelegramResponse:
    def __init__(self, payload, status_code=200):
        self.payload = payload
        self.status_code = status_code

    def json(self):
        return self.payload


class MockTelegramClient:
    is_closed = False

    def __init__(self, payload):
        self.payload = payload
        self.calls = []

    async def get(self, url, params):
        self.calls.append((url, params))
        return MockTelegramResponse(self.payload)


@pytest.mark.parametrize("link", ["javascript:alert(1)", "data:text/html,hello", "ftp://t.me/x", "https://"])
def test_invite_link_rejects_non_http_urls(link):
    with pytest.raises(ValidationError):
        tg_verify.GroupBody(username="@rsvx7", invite_link=link)


def test_group_id_and_private_invite_validation():
    assert tg_verify.GroupBody(username=" @public_group ").username == "@public_group"
    assert tg_verify.GroupBody(username="-1001234567890", invite_link="https://t.me/+invite").username == "-1001234567890"

    with pytest.raises(ValidationError):
        tg_verify.GroupBody(username="public_group")
    with pytest.raises(ValidationError):
        tg_verify.GroupBody(username="12345")
    with pytest.raises(ValidationError):
        tg_verify.GroupBody(username="-1001234567890", invite_link="http://t.me/+invite")
    with pytest.raises(ValidationError):
        tg_verify.GroupBody(username="-1001234567890")


@pytest.mark.parametrize(
    "result, expected",
    [
        ({"status": "restricted", "is_member": True}, (True, "restricted")),
        ({"status": "restricted", "is_member": False}, (False, "restricted")),
        ({"status": "member"}, (True, "member")),
    ],
)
def test_restricted_membership_requires_is_member(monkeypatch, result, expected):
    asyncio.run(_test_restricted_membership_requires_is_member(monkeypatch, result, expected))


async def _test_restricted_membership_requires_is_member(monkeypatch, result, expected):
    client = MockTelegramClient({"ok": True, "result": result})
    monkeypatch.setattr(tg_verify, "_membership_client", client)
    assert await tg_verify._check_one("test-token", "@rsvx7", 42) == expected


def test_membership_checks_are_bounded_and_share_mock_client(monkeypatch):
    asyncio.run(_test_membership_checks_are_bounded_and_share_mock_client(monkeypatch))


async def _test_membership_checks_are_bounded_and_share_mock_client(monkeypatch):
    groups = [
        {"_id": str(i), "username": f"@group_{i}", "name": f"G{i}", "invite_link": None}
        for i in range(7)
    ]
    active = 0
    max_active = 0
    calls = 0

    async def fake_check(_token, _chat_id, _user_id):
        nonlocal active, max_active, calls
        active += 1
        calls += 1
        max_active = max(max_active, active)
        # Yield so gather can exercise the semaphore.
        import asyncio
        await asyncio.sleep(0.001)
        active -= 1
        return True, "member"

    monkeypatch.setattr(tg_verify, "is_verification_enabled", lambda: _true_async())
    monkeypatch.setattr(tg_verify, "list_groups", lambda: _groups_async(groups))
    monkeypatch.setattr(tg_verify, "_get_bot_token", lambda: _token_async())
    monkeypatch.setattr(tg_verify, "_check_one", fake_check)

    result = await tg_verify.check_user_membership({"telegram": {"telegram_id": 42}})
    assert result["ok"] is True
    assert calls == len(groups)
    assert max_active <= tg_verify.MAX_MEMBERSHIP_CONCURRENCY == 5


def test_over_cap_configuration_fails_closed_without_telegram_calls(monkeypatch):
    asyncio.run(_test_over_cap_configuration_fails_closed_without_telegram_calls(monkeypatch))


async def _test_over_cap_configuration_fails_closed_without_telegram_calls(monkeypatch):
    groups = [
        {"_id": str(i), "username": f"@group_{i}", "name": f"G{i}", "invite_link": None}
        for i in range(tg_verify.MAX_REQUIRED_GROUPS + 1)
    ]
    called = False

    async def fake_check(*_args):
        nonlocal called
        called = True
        return True, "member"

    monkeypatch.setattr(tg_verify, "is_verification_enabled", lambda: _true_async())
    monkeypatch.setattr(tg_verify, "list_groups", lambda: _groups_async(groups))
    monkeypatch.setattr(tg_verify, "_check_one", fake_check)

    result = await tg_verify.check_user_membership({"telegram": {"telegram_id": 42}})
    assert result["ok"] is False
    assert result["reason"] == "group_count_exceeded"
    assert called is False
    assert len(result["groups"]) == tg_verify.MAX_REQUIRED_GROUPS


async def _true_async():
    return True


async def _groups_async(groups):
    return groups


async def _token_async():
    return "test-token"
