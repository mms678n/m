"""Per-platform-model routing with isolated records and provider fixtures."""
import asyncio
import copy
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
from fastapi import FastAPI, HTTPException
from fastapi.testclient import TestClient
from tests.test_builder import MemoryDB, USER, question_state, question_body, call
from tests.test_ai_settings_regressions import FakeStream
import ai_settings, auth, server, builder, workspace, tokens

DEFAULT = 'provider/default'
MODELS = {'kaligpt':'provider/fast', 'deepdark':'provider/reasoning', 'rsvx7-ai':'provider/coder'}
META = lambda model: {'model':model, 'context_length':48000 if model.endswith('reasoning') else 16000,
    'max_completion_tokens':2000, 'supported_parameters':['max_tokens', 'reasoning'] if model.endswith('reasoning') else ['max_tokens'],
    'reasoning': {'mandatory':True} if model.endswith('reasoning') else None}

def run(value): return asyncio.run(value)

@pytest.fixture
def store(monkeypatch):
    db = MemoryDB()
    db.users.rows['alice'] = copy.deepcopy(USER)
    db.projects.rows['p_owned'] = {'_id':'p_owned','user_id':'alice','name':'Project'}
    db.settings.rows['ai'] = {'_id':'ai', **META(DEFAULT), 'connection_revision':7,
        'provider_secret': ai_settings.credential_cipher().encrypt(b'fixture-only-provider-key-123').decode()}
    for module in (ai_settings, auth, builder, workspace, tokens): monkeypatch.setattr(module, 'db', db)
    monkeypatch.setattr(ai_settings, 'AI_PROVIDER', 'openrouter')
    monkeypatch.setattr(ai_settings, 'validate_catalog_model', AsyncMock(side_effect=lambda model: META(model)))
    monkeypatch.setattr(builder, 'current_settings', ai_settings.current_settings)
    monkeypatch.setattr(builder, 'require_membership', AsyncMock())
    builder._tasks.clear()
    return db

def api(role='super_admin'):
    app = FastAPI(); app.include_router(ai_settings.router); app.include_router(ai_settings.capabilities_router)
    app.dependency_overrides[auth.current_user] = lambda: {'_id':'operator','role':role,'permissions':[]}
    return TestClient(app)

def save(http, **extra):
    return http.put('/api/admin/ai-settings', json={'model':DEFAULT,'profile_models':MODELS,'model_revision':0,**extra})

def test_profiles_use_distinct_models_and_metadata_without_exposing_keys(store):
    with api() as http:
        response = save(http)
        assert response.status_code == 200, response.text
        assert response.json()['profile_models'] == MODELS
        assert response.json()['model_revision'] == 1
        caps = http.get('/api/ai/capabilities').json()['profiles']
        assert caps['deepdark']['reasoning_mandatory'] is True
        assert caps['kaligpt']['supports_reasoning'] is False
        assert [caps[p]['model'] for p in MODELS] == list(MODELS.values())
        assert 'provider_secret' not in response.text and 'fixture-only-provider-key' not in response.text
    assert store.settings.rows['ai']['connection_revision'] == 7
    assert ai_settings.configured_key(store.settings.rows['ai']) == 'fixture-only-provider-key-123'
    assert run(ai_settings.current_settings('deepdark'))['context_length'] == 48000
    assert run(ai_settings.current_settings('kaligpt'))['context_length'] == 16000
    assert run(ai_settings.current_settings('untrusted/profile'))['model'] == MODELS['rsvx7-ai']


def test_blank_assignment_inherits_default_and_legacy_default_update_preserves_overrides(store):
    with api() as http:
        assert save(http).status_code == 200
        clear = save(http, model='provider/new-default', profile_models={'deepdark':''}, model_revision=1)
        assert clear.status_code == 200
        assert clear.json()['profile_models']['deepdark'] == ''
        assert run(ai_settings.current_settings('deepdark'))['model'] == 'provider/new-default'
        assert run(ai_settings.current_settings('kaligpt'))['model'] == MODELS['kaligpt']
        legacy = http.put('/api/admin/ai-settings', json={'model':'provider/legacy-default'})
        assert legacy.status_code == 200
        assert legacy.json()['profile_models']['kaligpt'] == MODELS['kaligpt']
        assert run(ai_settings.current_settings('deepdark'))['model'] == 'provider/legacy-default'


def test_invalid_assignment_is_atomic_and_stale_revision_is_rejected(store, monkeypatch):
    async def catalog(model):
        if model == 'provider/missing': raise HTTPException(400, 'Unknown model')
        return META(model)
    monkeypatch.setattr(ai_settings, 'validate_catalog_model', AsyncMock(side_effect=catalog))
    before = copy.deepcopy(store.settings.rows['ai'])
    with api() as http:
        assert save(http, profile_models={**MODELS,'kaligpt':'provider/missing'}).status_code == 400
        assert store.settings.rows['ai'] == before
        assert save(http, profile_models={'forged':'provider/model'}).status_code == 422
        assert save(http).status_code == 200
        ai_settings.validate_catalog_model.reset_mock()
        assert save(http).status_code == 409
        ai_settings.validate_catalog_model.assert_not_awaited()
    with api('user') as http:
        assert save(http, model_revision=1).status_code == 403


def test_concurrent_settings_change_cannot_be_overwritten(store, monkeypatch):
    async def racing_catalog(model):
        store.settings.rows['ai']['model_revision'] = 3
        return META(model)
    monkeypatch.setattr(ai_settings, 'validate_catalog_model', racing_catalog)
    with api() as http: assert save(http).status_code == 409
    assert store.settings.rows['ai']['model'] == DEFAULT
    assert 'model_profiles' not in store.settings.rows['ai']


@pytest.mark.parametrize('profile', list(MODELS))
def test_chat_routes_and_bills_the_assigned_provider_not_browser_model(store, monkeypatch, profile):
    store.settings.rows['ai']['model_profiles'] = {p:META(m) for p,m in MODELS.items()}
    create = AsyncMock(return_value=FakeStream())
    monkeypatch.setattr(ai_settings,'select_client',lambda key:SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    monkeypatch.setattr(server,'current_settings',ai_settings.current_settings)
    for name in ('require_membership','check_can_afford','release_generation'):
        monkeypatch.setattr(server,name,AsyncMock())
    monkeypatch.setattr(server,'claim_generation',AsyncMock(return_value='fixture-lease'))
    monkeypatch.setattr(server,'charge_user',AsyncMock(return_value={'billed_total':1}))
    async def scenario():
        response = await server.chat_stream(server.ChatStreamRequest(personality=profile, model='attacker/arbitrary',
            dark_mode=False, messages=[{'role':'user','content':'Hello'}]), {'_id':'owner','role':'super_admin'})
        return ''.join([event async for event in response.body_iterator])
    assert '"t": "OK"' in run(scenario())
    assert create.call_args.kwargs['model'] == MODELS[profile]
    assert server.charge_user.call_args.kwargs['model'] == MODELS[profile]
    assert bool(create.call_args.kwargs['extra_body']) == (profile == 'deepdark')


def test_builder_job_pins_the_chosen_profile_and_retry_accepts_latest_admin_assignment(store, monkeypatch):
    store.settings.rows['ai']['model_profiles'] = {p:META(m) for p,m in MODELS.items()}
    question_state(store)
    async def pending(*args): await asyncio.Event().wait()
    monkeypatch.setattr(builder,'_run_job',pending)
    async def scenario():
        body = {**question_body(),'personality':'deepdark'}
        response = await call('/api/builder/projects/p_owned/run','alice','POST',body)
        assert response.status_code == 202, response.text
        job = response.json()['job']
        assert job['model'] == MODELS['deepdark']
        assert job['modelSettings']['context_length'] == 48000
        assert 'provider_secret' not in str(job)
        store.settings.rows['ai']['model_profiles']['deepdark'] = META('provider/replacement')
        assert store.projects.rows['p_owned']['builder']['job']['model'] == MODELS['deepdark']
        await call('/api/builder/projects/p_owned/cancel','alice','POST',{}); await asyncio.sleep(0)
        retry = await call('/api/builder/projects/p_owned/run','alice','POST',{'requestId':'retry-new-assignment','revision':0,'action':'retry'})
        assert retry.json()['job']['model'] == 'provider/replacement'
        assert len(store.projects.rows['p_owned']['builder']['messages']) == 2
        await call('/api/builder/projects/p_owned/cancel','alice','POST',{}); await asyncio.sleep(0)
        different = await call('/api/builder/projects/p_owned/run','alice','POST',{'requestId':'retry-other-profile','revision':0,'action':'retry','personality':'kaligpt'})
        assert different.json()['job']['model'] == MODELS['kaligpt']
        assert different.json()['job']['request']['action'] == 'answers'
        assert len(store.projects.rows['p_owned']['builder']['messages']) == 2
        await call('/api/builder/projects/p_owned/cancel','alice','POST',{}); await asyncio.sleep(0)
    run(scenario())


def test_builder_model_call_uses_accepted_job_snapshot_and_original_wallet(store, monkeypatch):
    import jwt
    pinned = META('provider/original-coder')
    store.projects.rows['p_owned']['builder'] = {**builder._empty(), 'job':{'id':'job-one','status':'running',
        'request':{'personality':'deepdark'},'modelSettings':pinned}}
    store.settings.rows['ai']['model_profiles'] = {'deepdark':META('provider/changed')}
    create = AsyncMock(return_value=FakeStream())
    monkeypatch.setattr(ai_settings,'select_client',lambda key:SimpleNamespace(chat=SimpleNamespace(completions=SimpleNamespace(create=create))))
    ticket = jwt.encode({'sub':'alice','pid':'p_owned','job':'job-one','aud':'rsvx7-builder-model'},auth.JWT_SECRET,algorithm='HS256')
    request = SimpleNamespace(headers={'Authorization':'Bearer '+ticket},is_disconnected=AsyncMock(return_value=False))
    body = builder.ModelBody(callId='pinned-provider-call',messages=[{'role':'user','content':'Hello'}])
    result = run(builder.model_call(body, request))
    assert result['text'] == 'OK'
    assert create.call_args.kwargs['model'] == pinned['model']
    usage = next(iter(store.token_usage_history.rows.values()))
    assert usage['model'] == pinned['model']
    assert store.users.rows['alice']['token_balance'] < USER['token_balance']
